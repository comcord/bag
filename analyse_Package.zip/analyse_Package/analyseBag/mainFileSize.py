#encoding: utf-8
#coding: utf-8
import MainProjectHelper
import os
import copy
import sys
fatherPath = os.path.join(sys.path[0],"../")
sys.path.append(fatherPath) 
import podConfig


class calculateHelper ():
    def GetPathSize(self,strPath):
        if not os.path.exists(strPath):
            # print "不存在" + strPath
            return 0
        if os.path.isfile(strPath):
            # print "是文件"
            return os.path.getsize(strPath)
        total_size = 0
        seen = {} 
        for dirpath, dirnames, filenames in os.walk(strPath):
            #get child directory size 
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    stat = os.stat(fp)
                except OSError:
                    continue

                try:
                    seen[stat.st_ino]
                except KeyError:
                    seen[stat.st_ino] = True
                else:
                    continue

                total_size += stat.st_size


        return total_size



# helper = PBXProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/localPods/BXSetting/Example/Pods/Pods.xcodeproj/project.pbxproj")
# helper = PBXProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/localPods/BXAboutMe/Example/BXAboutMe.xcodeproj/project.pbxproj")
# helper = MainProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/Pods/Pods.xcodeproj/project.pbxproj")




def resourceOutArr(path):
    projName = podConfig.podConfigClass().getProjectName()
    print "projName == " + projName
    helper = MainProjectHelper.PBXProjectHelper(path,projName)
    pathArr = helper.project.inputPathArr()
    # print pathArr
    # print "外面========"
    # print pathArr

    calculater = calculateHelper()

    # lastArr = []
    sumSize = 0
    for elements in pathArr:
        currentSize=calculater.GetPathSize(elements)
        sumSize = sumSize + currentSize


    print "========"
    print ""
    detail_module_map = {"resource": [], "config": [], "other": [], "code": [], "doric": []}

    allCycleArr=copy.deepcopy(pathArr)

    for urlPath in pathArr:
        urlPath = urlPath.strip()
        if urlPath.endswith('.xcassets') or urlPath.endswith('.png') or urlPath.endswith('.apng') or urlPath.endswith('.svg') or urlPath.endswith('.svga') or urlPath.endswith('.mp4') or urlPath.endswith('.mp3') or urlPath.endswith('.ttf') or urlPath.endswith('.bundle') or urlPath.endswith('.m4a') or urlPath.endswith('.wav') or urlPath.endswith('.webp') or urlPath.endswith('.aac'):
            if urlPath.endswith('doricprejs.bundle'):
                detail_module_map["doric"].append(urlPath)
            else:
                detail_module_map["resource"].append(urlPath)
        else:
            if urlPath.endswith('.js') or urlPath.endswith('.xml') or urlPath.endswith('.json') or urlPath.endswith('.plist') or urlPath.endswith('.otf') or urlPath.endswith('.zip') or urlPath.endswith('.lic') or urlPath.endswith('.proto') or urlPath.endswith('.tflite') or urlPath.endswith('.html'):
                detail_module_map["config"].append(urlPath)
            else:
                if urlPath.endswith('.h') or urlPath.endswith('.m') or urlPath.endswith('.storyboard'):
                    detail_module_map["code"].append(urlPath)
                else:
                    detail_module_map["other"].append(urlPath)
        

    # print "resource:"
    # print detail_module_map["resource"]
    # print ""

    # print ""
    # print "config:"
    # print detail_module_map["config"]

    # print ""
    # print "other:"
    # print detail_module_map["other"]

    resourceSize = 0
    for paths in detail_module_map["resource"]:
        resourceSize = resourceSize + calculater.GetPathSize(paths)

    # print "resource: " + str(resourceSize)

    configSize = 0
    mainConfigArr = []
    for paths in detail_module_map["config"]:
        configSize = configSize + calculater.GetPathSize(paths)
        mainConfigArr.append({paths: calculater.GetPathSize(paths)})

    print "主工程config总大小: " + str(configSize)
    print "主工程config大小详情: " + str(mainConfigArr)

    codeSize = 0
    for paths in detail_module_map["code"]:
        codeSize = codeSize + calculater.GetPathSize(paths)

    # print "code: " + str(codeSize)

    otherSize = 0
    for paths in detail_module_map["other"]:
        otherSize = otherSize + calculater.GetPathSize(paths)

    # print "other: " + str(otherSize)

    doricSize = 0
    for paths in detail_module_map["doric"]:
        doricSize = doricSize + calculater.GetPathSize(paths)

    detailSizeDic = {"resource": resourceSize, "config": configSize, "other": otherSize, "code": codeSize, "doric": doricSize}

    #code这里不统计进去，因为code用的都是linkmap里的
    sumSize = resourceSize + configSize + otherSize + doricSize

    return {"sumSize": sumSize, "detail_resource_dic": detailSizeDic}


if __name__ == "__main__":
    resourceOutArr("/Users/feijunjie/Desktop/比心/BXLife/YppLife.xcodeproj/project.pbxproj")







