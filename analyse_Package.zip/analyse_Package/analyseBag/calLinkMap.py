# coding: utf8

#
#   LinkMapParser
#   author:     eric.zhang
#   email:      zgzczzw@163.com
#

import sys
import os


def read_base_link_map_file(base_link_map_file):
    try:
        link_map_file = open(base_link_map_file)
    except IOError:
        print "Read file " + base_link_map_file + " failed!"
        return
    else:
        try:
            content = link_map_file.read()
        except IOError:
            print "Read file " + base_link_map_file + " failed!"
            return
        else:
            obj_file_tag_index = content.find("# Object files:")
            sub_obj_file_symbol_str = content[obj_file_tag_index + 15:]
            symbols_index = sub_obj_file_symbol_str.find("# Symbols:")
            if obj_file_tag_index == -1 or symbols_index == -1 or content.find("# Path:") == -1:
                print "The Content of File " + base_link_map_file + " is Invalid."
                pass
            link_map_file_tmp = open(base_link_map_file)
            reach_files = 0
            reach_sections = 0
            reach_symbols = 0
            size_map = {}
            while 1:
                line = link_map_file_tmp.readline()
                if not line:
                    break
                if line.startswith("#"):
                    if line.startswith("# Object files:"):
                        reach_files = 1
                        pass
                    if line.startswith("# Sections"):
                        reach_sections = 1
                        pass
                    if line.startswith("# Symbols"):
                        reach_symbols = 1
                        pass
                    pass
                else:
                    if reach_files == 1 and reach_sections == 0 and reach_symbols == 0:
                        index = line.find("]")
                        if index != -1:
                            symbol = {"file": line[index + 2:-1]}
                            key = int(line[1: index])
                            size_map[key] = symbol
                        pass
                    elif reach_files == 1 and reach_sections == 1 and reach_symbols == 0:
                        pass
                    elif reach_files == 1 and reach_sections == 1 and reach_symbols == 1:
                        symbols_array = line.split("\t")
                        if len(symbols_array) == 3:
                            file_key_and_name = symbols_array[2]
                            size = int(symbols_array[1], 16)
                            index = file_key_and_name.find("]")
                            if index != -1:
                                key = file_key_and_name[1:index]
                                key = int(key)
                                symbol = size_map[key]
                                if symbol:
                                    if "size" in symbol:
                                        symbol["size"] += size
                                        pass
                                    else:
                                        symbol["size"] = size
                                    pass
                                pass
                            pass
                        pass
                    else:
                        print "Invalid #3"
                        pass
            # size_map_sorted = sorted(size_map.items(), key=lambda y: y[1]["size"], reverse=True)
            # for item in size_map_sorted:
            #     print "%s\t%.3fM" % (item[1]["file"], item[1]["size"] / 1024.0 / 1024.0)
            #     pass
            total_size = 0
            a_file_map = {}
            for key in size_map:
                symbol = size_map[key]
                if "size" in symbol:
                    total_size += symbol["size"]
                    o_file_name = symbol["file"].split("/")[-1]
                    a_file_name = o_file_name.split("(")[0]
                    if a_file_name in a_file_map:
                        a_file_map[a_file_name] += symbol["size"]
                        pass
                    else:
                        a_file_map[a_file_name] = symbol["size"]
                        pass
                    pass
                else:
                    print "WARN : some error occurred for key ",
                    print key

            a_file_sorted_list = sorted(a_file_map.items(), key=lambda x: x[1], reverse=True)
            # print a_file_sorted_list
            return a_file_sorted_list

        finally:
            link_map_file.close()

      


def print_help():
    print "%s" % "=".ljust(80, '=')
    print "%s%s\n" % ("".ljust(10), "Link Map 文件分析工具".ljust(80))
    print "%s%s\n" % ("".ljust(10), "- Usage : python parselinkmap.py arg1 <arg2>".ljust(80))
    print "%s%s" % ("".ljust(10), "- arg1 ：基准LinkMap文件路径".ljust(80))
    print "%s%s\n" % ("".ljust(10), "- arg2 ：待比较LinkMap文件路径".ljust(80))
    print "%s%s" % ("".ljust(10), "备注：参数2为空时，只输出基准LinkMap分析结果".ljust(80))
    print "%s" % "=".ljust(80, '=')


def clean_result_file(file_name):
    if os.path.exists(file_name):
        os.remove(file_name)
        pass


def main():
    if len(sys.argv) == 2:
        need_compare = 0
        pass
    elif len(sys.argv) == 3:
        need_compare = 1
        pass
    else:
        print_help()
        return
        pass

    base_map_link_file = sys.argv[1]
    output_file_path = os.path.dirname(base_map_link_file)
    if output_file_path:
        base_output_file = output_file_path + "/BaseLinkMapResult.txt"
        pass
    else:
        base_output_file = "BaseLinkMapResult.txt"
        pass
    print "========ju"
    print base_map_link_file
    read_base_link_map_file(base_map_link_file)


    # clean_result_file(base_output_file)
    # clean_result_file(target_output_file)


if __name__ == "__main__":
    main()

