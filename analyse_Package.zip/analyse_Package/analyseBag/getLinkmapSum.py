#encoding: utf-8
#coding: utf-8

import calLinkMap
import os
# from calLinkMap import read_base_link_map_file


def outputLinkMap(path):
	a_file_sorted_list = calLinkMap.read_base_link_map_file(path)
	outputArr=[]
	lastArr=[]
	for elements in a_file_sorted_list:
		key=list(elements)[0]
		value=list(elements)[1]
		if key.startswith('lib'):
			aa=key.replace('lib','')
			bb=aa.split('.')[0]
			outputArr.append({bb: value})
			pass
		else:
			bb=key.split('.')[0]
			outputArr.append({bb: value})
		pass


	# print "当前linkmap统计的数组如下："
	return outputArr