# encoding: utf-8
# coding: utf-8
import os
import getLinkmapSum
import calFramework
import calculReourceSize
import mainFileSize
import shutil
import pdfkit
import copy
import sys 
fatherPath = os.path.join(sys.path[0],"../")
sys.path.append(fatherPath) 
import podConfig


def getPodDetail(podPath, linkmapPath, appPath, mainPath):
    mainResourceDic = mainFileSize.resourceOutArr(mainPath)
    resultMainSource = mainResourceDic.setdefault("sumSize", "")
    mainAllSizeDic = mainResourceDic.setdefault("detail_resource_dic", "")
    print ""
    print "主工程中资源归类：" + str(mainAllSizeDic)
    print ""
    print "主工程资源：" +'{:.2f}'.format(float((resultMainSource))/1024/1024) + "M"
    print ""


    resouce = calculReourceSize.resourceOutArr(podPath)

    resouceSizeArr = resouce.setdefault("podName", "")
    frameworkArr = resouce.setdefault("frameWork", "")
    #pod库中resource资源归类，各个资源维度下的总大小
    detailSizeDic = resouce.setdefault("detailSize_resource_dic", "")
    #pod库中resource资源归类，各个资源维度下 ———— 每个类中包含的资源的数组
    detail_List_dic = resouce.setdefault("detail_List_dic", "")
    print ""
    print "pod库中resource资源归类大小：" + str(detailSizeDic)
    print ""
    print "pod库中每个库对应的resource大小："
    print resouceSizeArr

    #记录到本地html文件中
    pod_resoureHtml_path = os.path.join(sys.path[0],"html/podResource.html")
    output_htmlFile(pod_resoureHtml_path, "每个pod库resource资源的大小", resouceSizeArr, "podResource.pdf")



    print ""
    print "pod库中resource资源归类，每个分类下，对应的库的大小："
    print detail_List_dic
    print ""
    resultResourceArr=copy.deepcopy(resouceSizeArr)
    # print frameworkArr

    # linkmap
    print ""
    linkmapArr = getLinkmapSum.outputLinkMap(linkmapPath)
    print "LinkMap相关打印如下："
    print linkmapArr
    resultLinkMapArr=copy.deepcopy(linkmapArr)

    #记录到本地html文件中
    pod_linkmapHtml_path = os.path.join(sys.path[0],"html/podLinkmap.html")
    output_htmlFile(pod_linkmapHtml_path, "每个pod库代码的大小", linkmapArr, "podLinkmap.pdf")


    # frameWork
    print ""
    currentFM = calFramework.getFrameworkSize(appPath)
    # print currentFM
    currentFMRemoveArr=copy.deepcopy(currentFM)
    print "currentFMRemoveArr first == " + str(currentFMRemoveArr)

    # 处理framework的映射关系，找到所属的库
    lastFrameArr = []
    for allFramework in frameworkArr:
        allkey = list(allFramework)[0]
        # allValue表示一个原始库包含的framework数量，可能是一个或者多个
        allValue = list(allFramework.values())[0]
        currentPodFramework = []
        for subFM in allValue:
            for needFMDic in currentFM:
                needFM = list(needFMDic)[0]

                if needFM in subFM:
                    # print needFM
                    # print subFM
                    # print "44444444"
                    # 如果动态库被包含，那么存一下这个动态库和大小
                    currentPodFramework.append(needFMDic)
                    #移除掉添加的这个
                    currentFMRemoveArr.remove(needFMDic)

        # 遍历完一个类后，看一下是否需要记录这个类
        if currentPodFramework:
            lastFrameArr.append({allkey: currentPodFramework})
            pass
        else:
            pass

    # print "currentFMRemoveArr last == " + str(currentFMRemoveArr)
    # print "动态库和类的映射如下："
    # print lastFrameArr
    mainFrameWorkSize = 0
    if currentFMRemoveArr:
        print "有没有分类的动态库，将要被分到主工程里：" + str(currentFMRemoveArr)
        for mainDic in currentFMRemoveArr:
            valueMainSize = list(mainDic.values())[0]
            mainFrameWorkSize = mainFrameWorkSize + valueMainSize
        pass
    mainAllSizeDic['framework'] = mainFrameWorkSize
    print "主工程中资源增加framework后，归类：" + str(mainAllSizeDic)
    updateLastFrameArr = []
    for frameDic in lastFrameArr:
        frameName = list(frameDic)[0]
        frameValue = list(frameDic.values())[0]
        currentFrameSize = 0
        for subFrameDic in frameValue:
            subFrameSize = list(subFrameDic.values())[0]
            currentFrameSize = currentFrameSize + subFrameSize

        updateLastFrameArr.append({frameName: currentFrameSize})

    print "更新后pod库所包含动态库大小如下："
    print updateLastFrameArr
    resultFrameWorkArr=copy.deepcopy(updateLastFrameArr)

    #记录到本地html文件中
    pod_frameWorkHtml_path = os.path.join(sys.path[0],"html/podFramework.html")
    outPutPdfFrameWorkArr=copy.deepcopy(updateLastFrameArr)
    if currentFMRemoveArr:
        outPutPdfFrameWorkArr = outPutPdfFrameWorkArr + currentFMRemoveArr
        pass
    output_htmlFile(pod_frameWorkHtml_path, "被打进包的动态库大小", outPutPdfFrameWorkArr, "podFramework.pdf")



    # 合并资源+linkmap+framework
    sumOneArr = []
    resourceSizeTwoArr = resouceSizeArr
    for linkDic in linkmapArr:
        linkName = list(linkDic)[0]
        linksize = list(linkDic.values())[0]
        sumsize = 0
        for resourceDic in resouceSizeArr:
            resouceName = list(resourceDic)[0]
            resoucesize = list(resourceDic.values())[0]
            if resouceName in linkName:
                # 匹配的话，记录并加入到数组里，跳出当前循环
                sumsize = linksize + resoucesize
                sumOneArr.append({resouceName: sumsize})
                resourceSizeTwoArr.remove(resourceDic)
                break
            else:
                pass

        if sumsize == 0:
            # 没有一个匹配的,说明此库没有resource
            sumOneArr.append(linkDic)
            pass

    # print "剩余的没有代码的资源类："
    # print resourceSizeTwoArr

    sumOneArr = resourceSizeTwoArr + sumOneArr

    # print "==========="
    # print sumOneArr

    sumTwoArr = []
    updateLastTwoFrameArr = updateLastFrameArr
    for sumADic in sumOneArr:
        sumAName = list(sumADic)[0]
        sumAsize = list(sumADic.values())[0]
        sumsize = 0
        for lastFrameDic in updateLastFrameArr:
            lastFrameName = list(lastFrameDic)[0]
            lastFrameSize = list(lastFrameDic.values())[0]
            if sumAName == lastFrameName:
                # 匹配的话，记录并加入到数组里，跳出当前循环
                sumsize = sumAsize + lastFrameSize
                sumTwoArr.append({sumAName: sumsize})
                updateLastTwoFrameArr.remove(lastFrameDic)
            else:
                pass

        if sumsize == 0:
            # 没有一个匹配的,说明此库没有framework
            sumTwoArr.append(sumADic)
            pass

    print ""
    # print "最后剩下的独立的framework："
    # print updateLastTwoFrameArr
    sumTwoArr = updateLastTwoFrameArr + sumTwoArr

    print ""
    print "========"
    print "最终所有库的大小如下："
    print sumTwoArr

    #记录到本地html文件中
    pod_All_path = os.path.join(sys.path[0],"html/allPodSumSize.html")
    output_htmlFile(pod_All_path, "每个pod库大小汇总（包含代码、资源、动态库等）", sumTwoArr, "allPodSumSize.pdf")



    # 所有pod库总大小（包含资源、代码、动态库）；  pod库对应的resource大小；  pod库中resource按照资源划分，每种资源下对应的总大小；  pod库中resource按照资源划分，每种资源下对应pod的数组
    # pod库代码大小，pod库动态库大小,主工程资源大小,主工程资源分类大小
    return {"everyPodSumSize": sumTwoArr, "everyPodResourceSize":resultResourceArr, "podResourceSortSize":detailSizeDic, "detail_List_dic": detail_List_dic, 
           "linkMapSize": resultLinkMapArr, "everyPodFrameWork":resultFrameWorkArr, "mainSumSize":resultMainSource, "mainSortSize":mainAllSizeDic}
    # return [sumTwoArr,resultResourceArr,resultLinkMapArr,resultFrameWorkArr,resultMainSource]
    pass


def removeDic(addArray, element, deleteArray):
    if element in deleteArray:
        addArray.append(element)
        deleteArray.remove(element)
        pass
    pass

#分类方法
#两个参数：1.分类选项数组(bx，yr，xyz等)，2.遍历的初始数组
def getDetailSort(output_module_map, cycleArray):
    helper = podConfig.podConfigClass()
    sortArr = helper.configDetail(output_module_map,cycleArray)
    return sortArr


#累加计算数组中的大小
def calculateSizeInArray(podArray):
    sumSize = 0
    for item in podArray:
        sumSize = list(item.values())[0] + sumSize
    return sumSize
    pass


def logWithParams(fh,fhDetail,needSortArray,detailString,resultMainSource,doricSize):
    detail_module_map = podConfig.podConfigClass().configSort()
    detail_module_map = getDetailSort(detail_module_map,needSortArray)

    nameConfigArr = podConfig.podConfigClass().configName()


    sumOtherSize=calculateSizeInArray(detail_module_map["other"])
    sumMainSize=calculateSizeInArray(detail_module_map["main"])

    #总大小
    sumAllSize = 0
    #各业务下的总大小
    workSumSizeStrArr = []
    outStringArr = []

    fh.write('<br>')
    fh.write('<br>')

    outLog_htmlFile(fh,"=========================================")
    fh.write('<font size="4" color="blue">%s从业务维度详细拆分，统计如下：</font>' % detailString)
    fh.write('<br>')

    for item in nameConfigArr:
        keyName = list(item)[0]
        valueName = list(item.values())[0]

        sumCurrentSize = calculateSizeInArray(detail_module_map[keyName])


        if "代码" in detailString:
            if keyName is "main":
                #如果是代码，主工程中统计用linkmap中剩下的other数据和main的划分数据
                sumCurrentSize = sumOtherSize + sumCurrentSize
                pass
            pass
        else:
            if keyName is "main":
                #正常情况下此时sumOtherSize和sumMainSize都是0，异常情况(有未分类的库)，先分到主工程里
                sumCurrentSize = resultMainSource + sumOtherSize + sumMainSize
                pass

        #当前业务下的总大小-字符串
        currentWorkNumStr = '{:.2f}'.format(float((sumCurrentSize))/1024/1024)

        if keyName is "main":
            currentWorkOutString = ("%s" % valueName) + detailString + "：" + currentWorkNumStr + "M"
        else:
            currentWorkOutString = ("%s：" % valueName) + currentWorkNumStr + "M"

        #所有库累加
        sumAllSize = sumAllSize + sumCurrentSize

        outLog_htmlFile(fh,currentWorkOutString)

        #将当前业务大小存一下
        workSumSizeStrArr.append(currentWorkNumStr)

        outStringArr.append(currentWorkOutString)



    doricNumStr = '{:.2f}'.format(float((doricSize))/1024/1024)
    doricOutString = "doric" + detailString + "：" + doricNumStr + "M"
    #再加上doric的大小
    sumAllSize = sumAllSize + doricSize
    sumAllOutString = "业务按照" + detailString + "划分，总计大小：" + '{:.2f}'.format(float(sumAllSize)/1024/1024) + "M"

    outLog_htmlFile(fh,doricOutString)
    outLog_htmlFile(fh,"=========================================")
    outLog_htmlFile(fh,sumAllOutString)

    workDetailTableSumStr = ""
    for item in workSumSizeStrArr:
        tempStr = '<td style="text-align:center;vertical-align:middle;">%s</td>' % item
        workDetailTableSumStr = workDetailTableSumStr + tempStr
        pass
    workDetailTableSumStr = workDetailTableSumStr + '<td style="text-align:center;vertical-align:middle;">%s</td>' % doricNumStr
    fhDetail.write('<tr><td>%s</td>%s</tr>' % (detailString, workDetailTableSumStr))

    print "========================================="
    print ""
    print detailString + "从业务维度详细拆分，统计如下："
    print ""

    for item in outStringArr:
        print item

    print doricOutString
    print "=========================================="
    print sumAllOutString
    print ""


#图片资源按照业务区分
def getDetailWithResource(fh,fhDetail,resultResourceArr,mainResourceSize):
    logWithParams(fh,fhDetail,resultResourceArr,"图片资源",mainResourceSize,0)
    pass


#根据业务区分代码大小
def getDetailWithLinkMap(fh,fhDetail,resultLinkMapArr, mainCodeSize):
    #代码只看linkmap，主工程的代码也被包含在
    logWithParams(fh,fhDetail,resultLinkMapArr,"代码",mainCodeSize,0)
    pass


#动态库按照业务区分
def getDetailWithFrameWork(fh,fhDetail,resultFrameWorkArr,mainOtherSize):
    logWithParams(fh,fhDetail,resultFrameWorkArr,"动态库",mainOtherSize,0)
    pass

#其他按照业务区分
def getDetailWithOther(fh,fhDetail,podOtherSortArrm,mainOtherSize):
    logWithParams(fh,fhDetail,podOtherSortArrm,"其他",mainOtherSize,0)
    pass

#配置文件按照业务区分
def getDetailWithConfig(fh,fhDetail,resourceConfigArr, mainConfigSize, doricSize):
    logWithParams(fh,fhDetail,resourceConfigArr,"配置文件",mainConfigSize,doricSize)
    pass

#按业务维度进行划分（包含详细划分）
def profession_module_detail(podSizeArr, resultResourceArr, podResourceSortDic, podDetail_List_dic, resultLinkMapArr, resultFrameWorkArr, resultMainSource, mainSortDic):
    # # 平台组件 & 基础组件 & 其他组件
    output_module_map = podConfig.podConfigClass().configSort()

    output_module_map = getDetailSort(output_module_map,podSizeArr)

    nameConfigArr = podConfig.podConfigClass().configName()
    print "nameConfigArr == %s" % str(nameConfigArr)

    #最终被打进包体的动态库，这里取得是剩下没有分类到对应库的，将被算到主工程里
    mainFMSize = mainSortDic.setdefault("framework","")

    #doric
    doricSize = mainSortDic.setdefault("doric","")

    print("\033[0;33;40m新增的库还没有分类，将统一被登记到主工程中，如下:\033[0m")
    print("\033[0;33;40m%s\033[0m" % output_module_map["other"])
    print ""
    sumOtherSize=calculateSizeInArray(output_module_map["other"])
    print("\033[0;33;40m%s\033[0m" % ("新增库大小总计：" + str(sumOtherSize)))
    if sumOtherSize != 0:
        print("\033[0;31;40m❗============请尽快对这些库进行分类！！！！===============\033[0m")
        print("\033[0;31;40m❗============请尽快对这些库进行分类！！！！===============\033[0m")
        print("\033[0;31;40m❗============请尽快对这些库进行分类！！！！===============\033[0m")
        print("\033[0;31;40m❗============请尽快对这些库进行分类！！！！===============\033[0m")
        
    else:
        print("\033[0;32;40m✅=============当前没有新增的库，很棒~~~~================\033[0m")
        print("\033[0;32;40m✅=============当前没有新增的库，很棒~~~~================\033[0m")
        print("\033[0;32;40m✅=============当前没有新增的库，很棒~~~~================\033[0m")
        print("\033[0;32;40m✅=============当前没有新增的库，很棒~~~~================\033[0m")
    print ""

    #总大小,这里先把划分到主工程中的动态库、主工程资源总大小和pod库划分的其他大小加上去，剩下的在下面的遍历中加起来
    sumAllSize = mainFMSize + sumOtherSize + resultMainSource

    #记录包体业务输出的打印日志
    analysePath = os.path.join(sys.path[0],"html/anlyseBag.html")
    fhh = open(analysePath, 'w')
    fhh.write('<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
    fhh.write('<font size="5" color="red">包体输出报表详细记录如下：</font>')
    fhh.write('<br>')
    fhh.write('<br>')
    fhh.write('<br>')

    outLog_htmlFile(fhh,"=========================================")
    fhh.write('<font size="4" color="red">按照业务维度划分，统计如下：</font>')
    fhh.write('<br>')

    outStringArr = []
    #业务分类名称，比如：基础业务、陪玩等
    workNameArr = []
    #各业务下的总大小
    workSumSizeStrArr = []

    for item in nameConfigArr:
        keyName = list(item)[0]
        valueName = list(item.values())[0]

        workNameArr.append(valueName)

        # print "%s:" % keyName
        # print ""
        # print output_module_map[keyName]
        sumCurrentSize = calculateSizeInArray(output_module_map[keyName])
        #当前业务下的总大小-字符串
        currentWorkNumStr = '{:.2f}'.format(float((sumCurrentSize))/1024/1024)
        #累加，算出总大小
        sumAllSize = sumAllSize + sumCurrentSize

        if keyName is "sq":
            #这里打印一下社区业务下的详细库，如果你想看别的，也可以把sq换成别的。全打印的话东西太多了
            print "%s:" % keyName
            print ""
            print output_module_map[keyName]

        if keyName is "main":
            print "%s:" % keyName
            print ""
            print output_module_map[keyName]
            print ""
            print "被划分到主工程中的库的大小是：" + str(sumCurrentSize)

            currentWorkNumStr = '{:.2f}'.format(float((resultMainSource - doricSize + sumOtherSize + sumCurrentSize + mainFMSize))/1024/1024)

        
        currentWorkOutString = ("%s：" % valueName) + currentWorkNumStr + "M"
        outLog_htmlFile(fhh,currentWorkOutString)

        outStringArr.append(currentWorkOutString)

        #将当前业务大小存一下
        workSumSizeStrArr.append(currentWorkNumStr)


        pass

    doricNumStr = '{:.2f}'.format(float((doricSize))/1024/1024)
    sumNumStr = '{:.2f}'.format(float((sumAllSize))/1024/1024)
    doricOutString = "doric资源：" + doricNumStr + "M"
    sumOUtString = "业务总计大小：" + sumNumStr + "M"

    outLog_htmlFile(fhh,doricOutString)
    outLog_htmlFile(fhh,"=========================================")
    outLog_htmlFile(fhh,sumOUtString)

    #打印一下
    print "========================================="
    print ""
    print "按照业务维度划分，统计如下："
    print ""
    for x in outStringArr:
        print x
    
    print doricOutString
    print "=========================================="
    print sumOUtString
    print ""

    #主工程代码大小，这里直接取0，后面统计用linkmap中的数据
    mainCodeSize = 0
    #主工程资源大小
    mainResourceSize = mainSortDic.setdefault("resource","")
    #主工程配置文件大小
    mainConfigSize = mainSortDic.setdefault("config","")
    #主工程其他文件大小
    mainOtherSize = mainSortDic.setdefault("other","")

    #pod库Resource中图片多媒体大小
    podResourceSize = podResourceSortDic.setdefault("resource","")
    #pod库Resource中配置文件大小
    podConfigSize = podResourceSortDic.setdefault("config","")
    #pod库Resource中其他文件大小
    podOtherSize = podResourceSortDic.setdefault("other","")

    #pod库Resource中图片多媒体分类下，对应的pod数组
    podResourceSortArr = podDetail_List_dic.setdefault("resource","")
    #pod库Resource中配置文件分类下，对应的pod数组
    podConfigSortArr = podDetail_List_dic.setdefault("config","")
    #pod库Resource中其他文件分类下，对应的pod数组
    podOtherSortArr = podDetail_List_dic.setdefault("other","")

    # print "pod库======"
    # print podResourceSize
    # print podConfigSize
    # print podOtherSize
    # print "podArr:"
    # print ""
    # print podResourceSortArr
    # print ""
    # print podConfigSortArr
    # print ""
    # print podOtherSortArr
    # print ""
    # print "dddd======="

    #包体报表形式输出html
    newBagPath = os.path.join(sys.path[0],"html/anlyseTable.html")
    newFile = open(newBagPath, 'w')
    newFile.write('<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
    newFile.write('<br>')
    newFile.write('<font size="6" color="black">包体多维度分析</font>')
    newFile.write('<br>')
    newFile.write('<br>')
    newFile.write('<font size="5" color="blue">业务总计大小：%sM</font>' % sumNumStr)
    newFile.write('<br>')
    newFile.write('<br>')
    if sumOtherSize != 0:
        newFile.write('<font size="5" color="red">============有尚未分组的类！！！！请尽快将其分类！</font>')
        newFile.write('<br>')
        newFile.write('<br>')
        pass

    #资源维度输出
    newFile.write('<font size="5" color="red">资源维度：</font>')
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">代码：项目中所有代码总和</font>')
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">多媒体资源：png，apng，svg，svga，mp4，mp3，.ttf，.bundle等</font>')
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">配置资源：json，js，xml，主工程中doric.bundle等</font>')
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">动态库：被打进包体的动态库</font>')
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">其他：签名文件，系统生成等</font>')
    newFile.write('<br>')
    newFile.write('<br>')
    newFile.write('<table border="1">')
    newFile.write('<tr><th> </th><th>代 码</th><th>多媒体资源</th><th>配置资源</th><th>动态库</th><th>其 他</th><tr>')
    newFile.write('<tr><td>%s</td><td style="text-align:center;vertical-align:middle;">%s</td><td style="text-align:center;vertical-align:middle;">%s</td><td style="text-align:center;vertical-align:middle;">%s</td><td style="text-align:center;vertical-align:middle;">%s</td><td style="text-align:center;vertical-align:middle;">%s</td></tr>' % ("size(M)", '{:.2f}'.format(float(calculateSizeInArray(resultLinkMapArr))/1024/1024), '{:.2f}'.format(float(calculateSizeInArray(podResourceSortArr) + mainResourceSize)/1024/1024), '{:.2f}'.format(float(calculateSizeInArray(podConfigSortArr) + mainConfigSize + doricSize)/1024/1024), '{:.2f}'.format(float(calculateSizeInArray(resultFrameWorkArr) + mainFMSize)/1024/1024), '{:.2f}'.format(float(calculateSizeInArray(podOtherSortArr) + mainOtherSize)/1024/1024)))
    newFile.write("</table>")

    newFile.write('<br>')
    newFile.write('<br>')
    newFile.write('<br>')

    #删除主工程
    workNameArr.pop()
    workExplainStr = ""
    workDetailTableExplainStr = ""
    for item in workNameArr:
        workExplainStr = workExplainStr + item + "、"
        workDetailTableExplainStr = workDetailTableExplainStr + "<th>" + item + "</th>"
        pass
    # if workExplainStr.endswith("、"):
    #     print "jjjjjjjj"
    #     workExplainStr = workExplainStr[::-1].replace('、','',1)[::-1]
    #     print workExplainStr
    #     pass
    workExplainStr = workExplainStr + "：pod库中的资源 + linkmap代码 + 被打进包体的动态库"
    workDetailTableExplainStr = workDetailTableExplainStr + "<th>主工程</th><th>doric</th>" 

    #业务维度
    newFile.write('<font size="5" color="red">业务维度：</font>')
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">%s</font>' % workExplainStr)
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">主工程：主工程中的资源(去除doric资源)+linkmap遗留下来的代码(比如一些系统的代码)</font>')
    newFile.write('<br>')
    newFile.write('<font size="2" color="black">doric：主工程中doric内置资源</font>')
    newFile.write('<br>')
    newFile.write('<br>')
    newFile.write('<table border="1">')


    newFile.write('<tr><th> </th>%s<tr>' % workDetailTableExplainStr)

    workDetailTableSumStr = ""
    for item in workSumSizeStrArr:
        tempStr = '<td style="text-align:center;vertical-align:middle;">%s</td>' % item
        workDetailTableSumStr = workDetailTableSumStr + tempStr
        pass
    workDetailTableSumStr = workDetailTableSumStr + '<td style="text-align:center;vertical-align:middle;">%s</td>' % doricNumStr
    newFile.write('<tr><td>%s</td>%s</tr>' % ("size(M)", workDetailTableSumStr))
    newFile.write("</table>")

    newFile.write('<br>')
    newFile.write('<br>')
    newFile.write('<br>')

    #详细拆分
    newFile.write('<font size="5" color="red">详细拆分：</font>')
    newFile.write('<br>')
    newFile.write('<table border="1">')
    newFile.write('<tr><th> </th>%s<tr>' % workDetailTableExplainStr)


    #代码维度
    getDetailWithLinkMap(fhh,newFile,resultLinkMapArr, mainCodeSize)
    #图片资源维度mainOtherSize
    getDetailWithResource(fhh,newFile,podResourceSortArr, mainResourceSize)
    #配置文件维度
    getDetailWithConfig(fhh,newFile,podConfigSortArr,mainConfigSize, doricSize)
    #framework维度
    getDetailWithFrameWork(fhh,newFile,resultFrameWorkArr,mainFMSize)
    #其他维度
    getDetailWithOther(fhh,newFile,podOtherSortArr,mainOtherSize)

    newFile.write("</table>")
    newFile.close()

    fhh.close()
    pdfkit.from_file(newBagPath,os.path.join(sys.path[0],"html/%s" % "anlyseTable.pdf"))

    


def inputPodSize(name, size):
    return '<tr><td>%s</td><td>%s</td><td>%s</td></tr>' % (name, size, '{:.2f}'.format(float(size)/1024/1024))

def save_to_file(fh,contents):
    fh.write(contents)

#输出html
def output_htmlFile(report_path, titleName, cycleArray, pdfName):
    fh = open(report_path, 'w')
    save_to_file(fh, '<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
    save_to_file(fh, '<font size="5" color="red">%s：</font>' % titleName)
    save_to_file(fh, '<br>')
    save_to_file(fh, '<table border="1">')
    save_to_file(fh, '<tr><th>podName</th><th>podSize / B</th><th>podSize / M</th><tr>')
    for eleDic in cycleArray:
        podName = list(eleDic)[0]
        podSize = list(eleDic.values())[0]
        save_to_file(fh,inputPodSize(podName,podSize))
    
    save_to_file(fh, "</table>")
    fh.close()
    pdfkit.from_file(report_path,os.path.join(sys.path[0],"html/%s" % pdfName))



#输出log日志的html
def outLog_htmlFile(fhh,contents):
    fhh.write(contents)
    fhh.write('<br>')
    pass


if __name__ == "__main__":
    if len(sys.argv) < 5:
    	print "缺少参数，参数请传全"
    	print "1. pod工程project.pbxproj文件； 2.主工程project.pbxproj文件； 3.包体.app文件； 4.linkmap文件 "
    	exit(0)

    #pod工程project.pbxproj参数
    podParams = sys.argv[1]
     #主工程参数project.pbxproj
    mainParams = sys.argv[2]
    #包体app参数
    lifeAppParams = sys.argv[3]
    #linkmap参数
    linkmapParams = sys.argv[4]


    #生成html文件夹，存放输出的html文件
    report_path = os.path.join(sys.path[0],"html")
    if os.path.exists(report_path):
        shutil.rmtree(report_path)

    os.mkdir(report_path)


    #linkmap参数
    #包体app参数
    #主工程参数
    sumDic = getPodDetail(podParams,linkmapParams,lifeAppParams,mainParams)
    #每个库的总大小
    everyPodSumSizeArr = sumDic.setdefault("everyPodSumSize","")
    #每个库的resource大小
    everyPodResourceSizeArr = sumDic.setdefault("everyPodResourceSize","")
    #pod库中resource资源归类，各个资源维度下的总大小
    podResourceSortDic = sumDic.setdefault("podResourceSortSize","")
    #pod库中resource资源归类，各个资源维度下 ———— 每个类中包含的资源的数组
    podDetail_List_dic = sumDic.setdefault("detail_List_dic","")
    #每个库在linkmap中统计大小
    linkMapSizeArr = sumDic.setdefault("linkMapSize","")
    #被打进包的pod库动态库大小
    everyPodFrameWorkArr = sumDic.setdefault("everyPodFrameWork","")
    #主工程所有资源总和
    mainSumSize = sumDic.setdefault("mainSumSize","")
    #主工程资源分类字典
    mainSortDic = sumDic.setdefault("mainSortSize","")

    profession_module_detail(everyPodSumSizeArr,everyPodResourceSizeArr,podResourceSortDic,podDetail_List_dic,linkMapSizeArr,everyPodFrameWorkArr,mainSumSize,mainSortDic)
