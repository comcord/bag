#encoding: utf-8
#coding: utf-8

import os
import sys


class calculateHelper ():
    def GetPathSize(self,strPath):
        if not os.path.exists(strPath):
            # print "不存在" + strPath
            return 0
        if os.path.isfile(strPath):
            # print "是文件"
            return os.path.getsize(strPath)
        total_size = 0
        seen = {} 
        for dirpath, dirnames, filenames in os.walk(strPath):
            #get child directory size 
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    stat = os.stat(fp)
                except OSError:
                    continue

                try:
                    seen[stat.st_ino]
                except KeyError:
                    seen[stat.st_ino] = True
                else:
                    continue

                total_size += stat.st_size


        return total_size


def curdir_size(path):
    ''' 计算当前文件夹下的所有文件的大小 '''
    all_files = os.listdir(path)
    file_dict = dict()
    lastArr=[]
    for each_file in all_files:
    	mbPath=path + "/" + each_file
    	size=calculateHelper().GetPathSize(mbPath)
    	# print each_file
    	# print size
        lastArr.append({each_file: size})

    return lastArr    

def traversalDir_FirstDir(path):
    list = []
    frameworkPath=''
    if (os.path.exists(path)):
        files = os.listdir(path)
        # print "22323"
        # print files
        for file in files:
            m = os.path.join(path,file)
            # print m
            if (os.path.isdir(m)):
                h = os.path.split(m)
                if h[1] == 'Frameworks':
                	print "111111"
                	frameworkPath=m
                	break
                	pass
                # print h[1]
                # list.append(h[1])
        # print list
        return frameworkPath
        

def getFrameworkSize(path):
    currentDir=traversalDir_FirstDir(path)
    lastArr=curdir_size(currentDir)
    return lastArr
    pass

