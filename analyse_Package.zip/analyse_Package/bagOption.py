#encoding: utf-8
#coding: utf-8

import sys
import os
import zipfile
import podConfig


def un_zip(file_name):
    """unzip zip file"""
    zip_file = zipfile.ZipFile(file_name)
    if os.path.isdir(file_name + "_zipFiles"):
        pass
    else:
        os.mkdir(file_name + "_zipFiles")
    for names in zip_file.namelist():
        zip_file.extract(names,file_name + "_zipFiles/")
    zip_file.close()


if len(sys.argv) < 5:
	print "缺少参数，参数请传全"
	print "1. pod工程project.pbxproj文件； 2.主工程project.pbxproj文件； 3.ipa包的目录； 4.linkmap文件 "
	exit(0)


#pod工程project.pbxproj参数
podParams = sys.argv[1]

#主工程参数project.pbxproj
mainParams = sys.argv[2]

#ipa包体目录
ipaPath = sys.argv[3]

#linkmap参数
linkmapParams = sys.argv[4]

print "ipa包目录是：" + ipaPath

newPath = ""
oldPath = ""

currentIpaPath = ipaPath
for name in os.listdir(currentIpaPath):
	portion = os.path.splitext(name)
	if portion[1] == '.ipa':
		oldPath = os.path.join(currentIpaPath,name)
		new_name = portion[0] + '.zip'
		newPath = os.path.join(currentIpaPath,new_name)
		os.rename(oldPath,newPath)
		break

# print "zipPath == " + newPath
# print "oldPath ==" + oldPath

if not newPath:
	print "未检测到ipa文件，请检查后重试"
	exit(0)

un_zip(newPath)

yppLifeName = newPath + "_zipFiles" + ("/Payload/%s.app" % podConfig.podConfigClass().getProjectName())
yppLifePath = os.path.join(currentIpaPath,yppLifeName)

print "yppLifePath == " + yppLifePath

if os.path.exists(yppLifePath):
	print "存在 包体.app文件: " + yppLifePath
	analyseBagPath = os.path.join(sys.path[0],"analyseBag/analyseBag.py")
	pythonStr = "python " + analyseBagPath + " " + podParams + " " + mainParams + " " + yppLifePath + " " + linkmapParams
	# print "pythonStr == " + pythonStr
	os.system(pythonStr)
else:
	print "不存在路径：" + yppLifePath
	exit(0)



