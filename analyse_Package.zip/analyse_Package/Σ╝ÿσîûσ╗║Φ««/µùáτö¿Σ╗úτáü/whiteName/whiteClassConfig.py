#encoding: utf-8
#coding: utf-8

mainArr = []

bxArr = ['BXRecPreferredGodInfoModel','BXIMDataModule','BXNotifyTipsPatternView','BXHomeNextLevelRouter','BXExploreUserHeadView',
          'BXFollowTopicRecent','BXCommonOrderPatternViewModel','BXCategoryGodListSpecialGameCell','BXLiveRouterImplementation',
          'BXInviteFriendDriveContentView','BXIMBannerModule','BXOfficialEventModel','BXExploreRecoRoomView','BXImageFullCardPatternModel',
          'BXMessageUpdateUserInfoAttach','BXMessegeHybridBridgeService','BXMessageCustomNoticeOrderExpiredAttachment','BXExploreTypeUserProtocol',
          'BXMessageCustomNoticeBubbleThemeAttachment','BXDevelopSelectApiURLViewController','BXWebStaticLinkConstant','BXSkillCardPatternModel',
          'BXCustomNoticeSvipAttachment','BXExplorePiashowHeadView','BXExploreType1Head','BXExploreType2Head','BXMessageGiftPatternViewModel',
          'BXUserCardContentView','BXSystemTipsPatternViewModel','BXExploreType2Body1R1','BXVoicePlayView','BXMessageCustomNoticeHeartwarmingAttachment',
          'BXCustomMessageTypeIntimateCurrentLevelRatioUpService','BXExploreType8Protocol','BXSendGameCardPatternView','BXDevelopUserInfoViewController',
          'BXCategoryGodListSpecialChannelCell','BXCustomNoticeAllowGodEnterRoomAttach','BXWalletRouterService','BXPublishGuideBOModel','BXContentPublishBoardInfoModel',
          'BXDevelopAudioDemoViewController','BXGroupPublicUpdateNoticeAttachment','BXFeedShareModel','BXFeedPlayTogetherLiveRoom','BXMCustomNoticeAuthorityAttach',
          'BXCategoryGodListCategoryNameModel','BXExploreRecoLiveRoomView','BXExploreType9Protocol','BXSameCityNewNearGodLiveInfo','BXExploreBaseProtocol',
          'BXMessageCustomNoticeUpdateBalanceAttachment','BXIMOrderModules','BXSettingAboutBXViewController','BXUserFeedPhotoModel','BXChatRoomOrderPatternView',
          'BXMessageCustomNoticeMoveSessionAttachment','BXBossTipsContentView','BXUserInfoConstants','BXMCustomNoticeVipUpgradeAttach','BXExploreType2Protocol',
          'BXHometownModel','BXShareGameContentView','BXLivePlayerManager','BXCreateTimeLineRouterService','BXSearchResultRequest','BXNotifyListItemPattern',
          'BXIMSessionTypeModel','BXMessageCustomNoticeShowBannerAttachment','BXSearchGameViewController','BXMessageCustomNoticeBgThemeAttachment',
          'BXGameCardPatternView','BXActivityCenterViewController','BXSelectedCatModel','BXEmojiPatternViewModel','BXCustomMessageRefreshGiftBagNoticeService',
          'BXMessageUpdateOrderCardAttachment','BXUIDTranslateTool','BXMessageOldAdminTableViewCell','BXMineRouterService','BXGroupUpdateNoticeAttachment',
          'BXDeveloperCommonViewController','BXImageFullCardPatternView','BXMessagePokeView','BXCommonCardPatternView','BXUserCardPatternModel','BXCommonCardPatternViewModel',
          'BXSellerRejectRefundDetailViewController','BXCheckstandWechatModel','BXMessageListViewController','BXMarketOrderPatternView','BXIMRedPacketPatternViewModel',
          'BXGroupKickNoticeAttachment','BXUserInfoPatternContentView','BXMCustomNoticeMonitorPushLogAttach','BXSettingDataModel','BXShareTimeLineContentView',
          'BXEditSkillCertIntroductionModel','BXIMGroupNavigationModule','BXMessageListRoomStatusNoticeAttachment','BXShareActivityContentView','BXGuideViewBorder',
          'BXCustomNoticeIntimacyBackgroundAttachment','BXCustomMessageGroupMuteNoticeService','BXMessageCustomNoticeFirstOrderAlertAttach','BXHomeAudioRoomViewController',
          'BXCheckStartServiceContentView','BXChatRoomPatternModel','BXAtPatternViewModel','BXIMMessageModule','BXSchemeHistoryListViewController','BXChatBackgroundModel',
          'BXHomeVideoFeedsRouter','BXContentDrawTitleModel','BXShareGodProfileContentView','BXMutableStatusViewModel','BXGroupDismissNoticeAttachment',
          'BXUserCardPatternView','BXCustomMessageTypeIntimateBeActiveService','BXProcessPromptMessageContentView','BXExploreTypeUserView','BXIAPService',
          'BXCategoryGodListContentCell','BXExploreRoomHeadView','BXIMSessionTextContentView','BXCategoryGodListFilterCell','BXInviteOrderPatternView',
          'BXIMInviteToEnterRoomPatternViewModel','BXFollowTopicRecCategory','BXLiveService','BXCommonCardContentView','BXCategoryGodListCell','BXCustomMessageGroupChangedUserNicknameAttachment',
          'BXMessageIntimacyRewardModel','BXSkillCardPatternView','BXMessageCustomNoticeChatroomAttachment','BXMessagePatternSVIPGiftViewModel','BXCategoryGodListSingingRoomsCell',
          'BXTopicButtonVO','BXMessageKitConstants','BXIMGroupMessageModule','BXMessageCustomNoticeOrderStatusChangeAttachment','BXContentAtPreInfoModel',
          'BXMessageCustomNoticeGodSkillDetailAttachment','BXTopicListViewController','BXShareLiveOrChatRoomContentView','BXIMGroupNoticeModule','BXCustomMessageTypeIntimateLevelUpService',
          'BXSchemeListViewController','BXBlurContentConfig','BXPokePatternViewModel','BXIMGroupBannerModule','BXDeveloperMessageListViewController','BXAudioTipContentView',
          'BXMessageCustomNoticeSayHelloAttachment','BXEnterExpireCheck','BXAccountService','BXMessageCustomNoticeJumpSetting','BXMessageCustomNoticeUpdateGameOrderAttachment',
          'BXIMNavigationModule','BXMCustomNoticeBadgeInfoAttach','BXIMTextContentConfig','BXIMGroupDataModule','BXSameCityTopHotRecommendModel','BXCustomNoticeBXSvipAuthority']
sqArr = []

yrArr = ['CRInQueueViewController','CRBubbleDisabledRecommendVC','ZedPagingModel','CRCollectionTypeTagHeader','ZedTwoLinesText','YRRadioJoinGuardGroupView',
         'ZedDialogView','CRGameGiftRequestModel','ZedMixedLayout','CRBXDispatchCouponModel','CRCollectionTagHeader','CRGoldSeatConfigModel','CRCollectionDarkTagHeader',
         'YRProtocolAliEventTrack','CRHomeConst','CRRedPacketView','ZedAppkitConfigure','ZedCompositeLayout','CRChatRoomStatusModel','CRGradientLayerView',
         'CRPrivateUserFollowListModel','CRCollectionDarkTypeTagCell','CRGlobalPriorityViewController','YRNoMoreDataView','CRGangUpEditTextCell','ZedToolkitConstants',
         'CRHomeListAnchorDispatchConstants','YRFadeBannerView','CRGangupCheckModel','CRHomeListBaseModel','CRGangUpEditOptionCell','CRGangUpEditCardCell',
         'CRHomeListOrderTabViewController','CRPPSandboxViewController','CRChatRoomListTabViewController','ZedPlayerContainer','ZedSheetAction','CRRewardReceptionGiftRequestModel',
         'CRFlowLabelCollectionViewCellModel','ZedMoreView','CRCollectionDarkTagCell','CRPopViewController','CRGodApplayToast','ZedSearchBar','CRCollectionTagCell',
         'ZedOneLineSwitch','ZedAudioWaveManager','ZedResourceManager','ZedAlignedImageView','ZedNumberUtil','CRRedPacketSendViewController','ZedOneLineText','CRMiddleBossInfoModel',
         'YRActionsView','CRFollowResponceModel','CRHeaderViewController','ZedDimTextContentView','CRGangupMatchTagCell','CRGangUpEditTimeCell','YRRadioGuardGroupDescView',
         'ZedReportManager','YuerColorUtil','YRTagLabelTool','ZedWaveView','CRFlowLabelCollectionView','YRActionSheet','CREnterViewController','CRRepeatOrderModel']

xyzArr = ['XYZLiveHelperVC','XYZLiveHalfWebService','XYZPhotoSelectBrowser','XYZEditImageView','XYZCollectionViewLeftAlignedLayout','XYZSearchModel',
          'XYZLiveAnchorRoundRoomPrepareViewController','XYZMineNormalCell','XYZLuxInputView','XYZWalletBannerView','XYZSearchUserIconModel',
          'XYZThirdShareView','XYZLiveIconModel','XYZIconsConfiguration','XYZLiveAnchorLoadService','XYZLiveListTabViewController','XYZLogUtility',
          'XYZBasePushView','XYZUserTableViewCell','XYZVideoVC','XYZBasePushModel','XYZPopupView','XYZ9BoxImageView','XYZThirdConfig','XYZConstants',
          'XYZLiveMemberModel','XYZActivityIndicatorView','XYZContactAlertVC']

orderArr = ['BXGodConstants','BXGodHomeListViewController','BXOrderPreloadService','BXGodHomeListTableViewCell','BXGodCategoryReplyRateModel',
            'BXGodHomeListMultiActivityView','BXOrderReviewCertificateFileModel','BXOrderCompletePatternViewModel','BXOrderConstants','BXOrderSellerUploadCerViewController',
            'BXGodHomeListActivityView','BXOrderGameGlobalBannerView','BXGodHomeListChatRoomTableCell','BXGodHomeListLiveRoomTableCell']
gameArr = []

archArr = ['YppFizzTableViewCell','YppBlockHookUtil','YppH5GameModel','YppBugIssueScreenShotCell','YppCheckAvatarIsFaceRequest','YppBubbleBaseView',
           'YppFizzCollectionViewController','YppPersonalChatroomAgreementViewController','YppLarkifyViewController','YppAudioTencentEngineService',
           'YppBugViewController','YppMockUrlViewController','YppFizzTableViewController']

otherArr = []


whiteConfigArr = mainArr + bxArr + sqArr + yrArr + xyzArr + orderArr + gameArr + archArr + otherArr





def getWhiteConfigArr():
	print "====whiteClassConfigArr获取======"
	return whiteConfigArr