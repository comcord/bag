#encoding: utf-8
#coding: utf-8

import os
import re
import sys
import shutil
import copy
import pdfkit
import FindAllClassIvars
import json
currentHeader = (sys.path[0]).split('Res/analyse_Packag')[0]
fatherPath = os.path.join(currentHeader,"Res/analyse_Package")
whiteConfigPath = os.path.join(currentHeader,"Res/analyse_Package/优化建议/无用代码/whiteName")
print "whiteConfigPath == " + str(whiteConfigPath)
sys.path.append(whiteConfigPath)
import whiteClassConfig

def verified_app_path(path):
    if path.endswith('.app'):
        appname = path.split('/')[-1].split('.')[0]
        path = os.path.join(path, appname)
        if appname.endswith('-iPad'):
            path = path.replace(appname, appname[:-5])
    if not os.path.isfile(path):
        return None
    if not os.popen('file -b ' + path).read().startswith('Mach-O'):
        return None
    return path


def pointers_from_binary(line, binary_file_arch):
    if len(line) < 16:
        return None
    line = line[16:].strip().split(' ')
    pointers = set()
    if binary_file_arch == 'x86_64':
        #untreated line example:00000001030cec80	d8 75 15 03 01 00 00 00 68 77 15 03 01 00 00 00
        if len(line) != 16:
            return None
        pointers.add(''.join(line[4:8][::-1] + line[0:4][::-1]))
        pointers.add(''.join(line[12:16][::-1] + line[8:12][::-1]))
        return pointers
    #arm64 confirmed,armv7 arm7s unconfirmed
    if binary_file_arch.startswith('arm'):
        #untreated line example:00000001030bcd20	03138580 00000001 03138878 00000001
        if len(line) != 4:
            return None
        pointers.add(line[1] + line[0])
        pointers.add(line[3] + line[2])
        return pointers
    return None


def class_ref_pointers(path, binary_file_arch):
    print '获取项目中所有被引用的类...'
    ref_pointers = set()
    lines = os.popen('/usr/bin/otool -v -s __DATA __objc_classrefs %s' % path).readlines()
    for line in lines:
        pointers = pointers_from_binary(line, binary_file_arch)
        if not pointers:
            continue
        ref_pointers = ref_pointers.union(pointers)
    if len(ref_pointers) == 0:
        exit('Error:class ref pointers null')
    return ref_pointers


def class_list_pointers(path, binary_file_arch):
    print '获取项目中所有的类...'
    list_pointers = set()
    lines = os.popen('/usr/bin/otool -v -s __DATA __objc_classlist %s' % path).readlines()
    for line in lines:
        pointers = pointers_from_binary(line, binary_file_arch)
        if not pointers:
            continue
        list_pointers = list_pointers.union(pointers)
    if len(list_pointers) == 0:
        exit('Error:class list pointers null')
    return list_pointers


def filter_use_load_class(path, binary_file_arch):
    print('获取项目中所有使用load方法的类...')
    list_load_class = set()
    lines = os.popen('/usr/bin/otool -v -s __DATA __objc_nlclslist %s' % path).readlines()
    for line in lines:
        pointers = pointers_from_binary(line, binary_file_arch)
        if not pointers:
            continue
        list_load_class = list_load_class.union(pointers)
    return list_load_class


def class_symbols(path):
    print '通过符号表中的符号，获取类名...'
    symbols = {}
    #class symbol format from nm: 0000000103113f68 (__DATA,__objc_data) external _OBJC_CLASS_$_TTEpisodeStatusDetailItemView
    re_class_name = re.compile('(\w{16}) .* _OBJC_CLASS_\$_(.+)')
    lines = os.popen('nm -nm %s' % path).readlines()
    for line in lines:
        result = re_class_name.findall(line)
        if result:
            (address, symbol) = result[0]
            symbols[address] = symbol
    if len(symbols) == 0:
        exit('Error:class symbols null')
    return symbols

def filter_super_class(unref_symbols,paths):
    re_subclass_name = re.compile("\w{16} 0x\w{9} _OBJC_CLASS_\$_(.+)")
    re_superclass_name = re.compile("\s*superclass 0x\w{9} _OBJC_CLASS_\$_(.+)")
    #subclass example: 0000000102bd8070 0x103113f68 _OBJC_CLASS_$_TTEpisodeStatusDetailItemView
    #superclass example: superclass 0x10313bb80 _OBJC_CLASS_$_TTBaseControl
    print "ppppppppp === " + str(paths)
    lines = os.popen("/usr/bin/otool -oV %s" % paths).readlines()
    subclass_name = ""
    superclass_name = ""
    for line in lines:
        subclass_match_result = re_subclass_name.findall(line)
        if subclass_match_result:
            subclass_name = subclass_match_result[0]
        superclass_match_result = re_superclass_name.findall(line)
        if superclass_match_result:
            superclass_name = superclass_match_result[0]

        if len(subclass_name) > 0 and len(superclass_name) > 0:
            if superclass_name in unref_symbols and subclass_name not in unref_symbols:
                unref_symbols.remove(superclass_name)
            superclass_name = ""
            subclass_name = ""
    return unref_symbols

def class_unref_symbols(path,reserved_prefix,filter_prefix):
    #binary_file_arch: distinguish Big-Endian and Little-Endian
    #file -b output example: Mach-O 64-bit executable arm64
    binary_file_arch = os.popen('file -b ' + path).read().split(' ')[-1].strip()
    unref_pointers = class_list_pointers(path, binary_file_arch) - (class_ref_pointers(path, binary_file_arch) | filter_use_load_class(path, binary_file_arch) )
    if len(unref_pointers) == 0:
        exit('Finish:class unref null')

    symbols = class_symbols(path)
    unref_symbols = set()
    for unref_pointer in unref_pointers:
        if unref_pointer in symbols:
            unref_symbol = symbols[unref_pointer]
            if len(reserved_prefix) > 0 and not unref_symbol.startswith(reserved_prefix):
                continue
            if len(filter_prefix) > 0 and unref_symbol.startswith(filter_prefix):
                continue
            unref_symbols.add(unref_symbol)
    if len(unref_symbols) == 0:
        exit('Finish:class unref null')

    unref_symbolsTwo = filter_super_class(unref_symbols,path)
    print "静态检查获取无用类总数：%d个" % len(unref_symbolsTwo)
    unref_symbols, find_ivars_class_list = find_ivars_is_unuse_class(path,unref_symbolsTwo)
    print "其中作为其他类属性的类，数量是：%d个" % len(find_ivars_class_list)
    print "剩下的无用类的数量是：%d个" % len(unref_symbols)
    return unref_symbols
    # return filter_super_class(unref_symbols)


# 查找所有的未使用到的类，是否出现在了相关类的属性中
# 自己作为自己的属性不算
def find_ivars_is_unuse_class(path, unref_sels):
    # {'MyTableViewCell':
    # [{'ivar_name': 'superModel', 'ivar_type': 'SuperModel'}, {'ivar_name': 'showViewA', 'ivar_type': 'ShowViewA'}, {'ivar_name': 'dataSource111', 'ivar_type': 'NSArray'}],
    # 'AppDelegate': [{'ivar_name': 'window', 'ivar_type': 'UIWindow'}]}
    imp_ivars_info = FindAllClassIvars.get_all_class_ivars(path)
    temp_list = list(unref_sels)
    find_ivars_class_list = []
    unref_symbols = copy.deepcopy(unref_sels)
    for unuse_class in temp_list:
        for key in imp_ivars_info.keys():
            # 当前类包含自己类型的属性不做校验
            if key == unuse_class:
                continue
            else:
                ivars_list = imp_ivars_info[key]
                is_find = 0
                for ivar in ivars_list:
                    if unuse_class == ivar["ivar_type"]:
                        unref_symbols.remove(unuse_class)
                        find_ivars_class_list.append(unuse_class)
                        is_find = 1
                        break
                if is_find == 1:
                    break

    return unref_symbols, find_ivars_class_list



def writeInTableFile(fh,pathArr,titleName,pathTwo,ownerName,globleNameArr):
    if not pathArr:
        return
    addPathNamer(ownerName,titleName,len(pathArr),globleNameArr)
    fh.write('<br>')
    fh.write('<br>')
    fh.write('<br>')
    fh.write('<font size="5" color="blue">%s：</font>' % titleName)
    fh.write('<br>')
    fh.write('<font size="4" color="red">负责人：%s</font>' % ownerName)
    fh.write('<table border="1">')
    if pathTwo is "y":
        fh.write('<tr><th>className</th><th>进度</th><th>备注</th><tr>')
    else:
        fh.write('<tr><th>className</th><tr>')
    for elePath in pathArr:
        if pathTwo is "y":
            fh.write('<tr><td>%s</td><td></td><td></td></tr>' % elePath)
        else:
            fh.write('<tr><td>%s</td></tr>' % elePath)

    fh.write("</table>")    


def queryArrInTableFile(fh,pathArr,titleName):
    if not pathArr:
        return
    fh.write('<br>')
    fh.write('<font size="4" color="black">%s：%s 个</font>' % (titleName, len(pathArr)))


def addPathNamer(nameStr,moduleStr,count,globleNameArr):
    if count > 0:
        globleNameArr.append({moduleStr:[nameStr,count]})
        pass
    pass


def optionUnUseClass(appPath,caidan):
    print ""
    print ""
    print "*********************无用类检测开始*********************"
    path = verified_app_path(appPath)
    print "optionPath == " + str(path)
    pathTwo = caidan
    if not path:
        sys.exit('Error:invalid app path')

    reserved_prefix = ''
    filter_prefix = ''
    unref_symbols = class_unref_symbols(path, reserved_prefix, filter_prefix)
    script_path = sys.path[0].strip()
    # f = open(script_path + '/result.txt','w')
    # f.write('classunrefs count: %d\n' % len(unref_symbols))
    # f.write('Precondition: reserve class startwiths \'%s\', filter class startwiths \'%s\'.\n\n' %(reserved_prefix, filter_prefix))
    # for m in unref_symbols:
    #     if (not "Plugin" in m) and (m.startswith('Zed') or m.startswith('Yuer') or m.startswith('Ypp') or m.startswith('BX') or m.startswith('XYZ') or m.startswith('YDS') or m.startswith('YPS') or m.startswith('CR') or m.startswith('YR')):
    #         print m
    #         f.write(m + "\n")
    # f.close()

    # print 'Done! result.txt already stored in script dir.'

    classArr = []
    for m in unref_symbols:
        if (not "Plugin" in m) and (m.startswith('Zed') or m.startswith('Yuer') or m.startswith('Ypp') or m.startswith('BX') or m.startswith('XYZ') or m.startswith('YDS') or m.startswith('YPS') or m.startswith('CR') or m.startswith('YR')):
            # print m
            classArr.append(m)


    # classArr = ['BXUserPageBizTagModel','ZedDimTextContentView','CREnterUserInfo','XYZLiveIMService','PodsDummy_SonaRoom']
    # print classArr
    print "最后，过滤掉一些不处理的类，剩下的无用类的数量是：%d个" % len(classArr)

    whiteArr = whiteClassConfig.getWhiteConfigArr()
    print "白名单列表：" + str(whiteArr)
    if whiteArr:
        classTwoArr = copy.deepcopy(classArr)
        for currentClass in classTwoArr:
            for needRemoveClass in whiteArr:
                if needRemoveClass in currentClass:
                    classArr.remove(currentClass)
                    break
                pass
            pass
        pass

    print "再过滤掉白名单的类，剩下的无用类的数量是：%d个" % len(classArr)
    output_module_map = {"bx": [], "yr": [], "xyz": [], "other": [], "arch": [], "order": []}
    for elements in classArr:
        if elements.startswith('BX'):
            output_module_map["bx"].append(elements)
        else:
            if elements.startswith('Yuer') or elements.startswith('CR') or elements.startswith('YR') or elements.startswith('Zed'):
                output_module_map["yr"].append(elements)
            else:
                if elements.startswith('XYZ'):
                    output_module_map["xyz"].append(elements)
                else:
                    if elements.startswith('Ypp'):
                        output_module_map["arch"].append(elements)
                    else:
                        print "1111111"
                        print elements
                        output_module_map["other"].append(elements)
        pass


    cycleArr = copy.deepcopy(output_module_map["bx"])
    for item in cycleArr:
        if item.startswith('BXOrder') or item.startswith('BXGod'):
            output_module_map["order"].append(item)
            output_module_map["bx"].remove(item)
        pass
    print "bx:"
    print ""
    print output_module_map["bx"]

    print "order:"
    print ""
    print output_module_map["order"]

    print "yr:"
    print ""
    print output_module_map["yr"]

    print "xyz:"
    print ""
    print output_module_map["xyz"]

    print "arch:"
    print ""
    print output_module_map["arch"]

    print "other:"
    print ""
    print output_module_map["other"]

    globleNameArr = []

    currentPath = os.path.join(fatherPath,"优化建议/无用代码")
    report_path = os.path.join(currentPath,"html")
    if os.path.exists(report_path):
        shutil.rmtree(report_path)

    os.mkdir(report_path)

    pod_resoureHtml_path = os.path.join(currentPath,"html/uselessCode.html")


    fh = open(pod_resoureHtml_path, 'w')
    fh.write('<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
    fh.write('<font size="5" color="red">无用类整理如下：</font>')

    fh.write('<br>')
    fh.write('<br>')
    fh.write('<font size="4" color="blue">本次检测查询得到的业务组如下：</font>')
    fh.write('<br>')


    queryArrInTableFile(fh,output_module_map["bx"],"比心BX")
    queryArrInTableFile(fh,output_module_map["order"],"陪玩Order")
    queryArrInTableFile(fh,output_module_map["yr"],"语音聊天室YR")
    queryArrInTableFile(fh,output_module_map["xyz"],"直播XYZ")
    queryArrInTableFile(fh,output_module_map["arch"],"架构")
    queryArrInTableFile(fh,output_module_map["other"],"其他")

    fh.write('<br>')
    fh.write('<br>')
    fh.write('<br>')
    fh.write('<font size="4" color="blue">详情如下：</font>')


    writeInTableFile(fh,output_module_map["bx"],"比心BX",pathTwo,'费俊杰',globleNameArr)
    writeInTableFile(fh,output_module_map["order"],"陪玩Order",pathTwo,'李军灼',globleNameArr)
    writeInTableFile(fh,output_module_map["yr"],"语音聊天室YR",pathTwo,'汪涛',globleNameArr)
    writeInTableFile(fh,output_module_map["xyz"],"直播XYZ",pathTwo,'刘立',globleNameArr)
    writeInTableFile(fh,output_module_map["arch"],"架构",pathTwo,'费俊杰',globleNameArr)
    writeInTableFile(fh,output_module_map["other"],"其他",pathTwo,'费俊杰',globleNameArr)

    fh.close()
    pdfkit.from_file(pod_resoureHtml_path,os.path.join(currentPath,"html/%s" % "uselessCode.pdf"))

    print "NameArr == " + json.dumps(globleNameArr, encoding="UTF-8",ensure_ascii=False)
    print "====================无用类检测完毕===================="
    print ""
    print ""
    return globleNameArr
    pass

if __name__ == '__main__':
    print sys.argv
    if len(sys.argv) < 2:
        print "缺少参数，参数请传全"
        print 'Please input app path\nFor example:/Users/yuencong/Library/Developer/Xcode/DerivedData/***/Build/Products/Dev-iphoneos/***.app\n'
        exit(0)
    # path = verified_app_path(sys.argv[1])
    # path = ""
    # print "ttt == " + str(path)
    optionUnUseClass(sys.argv[1],"")






