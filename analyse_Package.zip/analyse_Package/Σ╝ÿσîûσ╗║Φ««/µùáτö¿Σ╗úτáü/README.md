# classunref
查找OC中未使用的类

执行 python classunrefs.py xxx.app

用debug环境的可执行文件分析，因为比心的release环境下会开启一些边缘选项，
部分符号缺失和优化，导致分析失败

输入的第一个参数为xxx.app，可以把Xcode products目录下的xxx.app拖到命令行，这个参数是为了拿到.app下的mach-o文件，分析使用的类和未使用的类。



#### 1.彩蛋

跟第三个参数y，可以得到登记列表样式。