#encoding: utf-8
#coding: utf-8
import os
import sys

repeatDesPath = os.path.join(sys.path[0],"./重复资源")
sys.path.append(repeatDesPath)
import getRepeatPic

bigDesPath = os.path.join(sys.path[0],"./获取工程大图")
sys.path.append(bigDesPath)
import getAllBigPic

unUseDesPath = os.path.join(sys.path[0],"./无用资源")
sys.path.append(unUseDesPath)
import UnusedPicture

unRefClassPath = os.path.join(sys.path[0],"./无用代码")
sys.path.append(unRefClassPath)
import classunrefs

currentPath = sys.path[0]
currentHeader = currentPath.split('Res/analyse_Package')[0]
desPath = currentHeader
print str(desPath)

import sendOption


sendArr = []

#主工程project.pbxproj文件
print ""
mainPbxproj = os.path.join(desPath,"YppLife.xcodeproj/project.pbxproj")
print "mainPbxproj == " + str(mainPbxproj)

#pod工程project.pbxproj文件
print ""
podPbxproj = os.path.join(desPath,"Pods/Pods.xcodeproj/project.pbxproj")
print "podPbxproj == " + str(podPbxproj)

#大图检测大小，图片大小，小于50默认为50 (单位k)
bigMax = 200

#重复资源检测pod目录
print ""
repeatResourcePodPath = os.path.join(desPath,"Pods")
print "repeatResourcePodPath == " + str(repeatResourcePodPath)

#重复资源检测主工程目录
print ""
repeatResourceMainPath = os.path.join(desPath,"YppLife")
print "repeatResourceMainPath == " + str(repeatResourceMainPath)

#无用资源检测目录
print ""
unUsePicPath = desPath
print "unUsePicPath == " + str(unUsePicPath)

#无用类检测目录
print ""
unAppClassPath = os.path.join(desPath,"Res/analyse_Package/tempApp/Debug-iphonesimulator/YppLife.app");
if os.path.exists(unAppClassPath):
	print "YppLife.app存在路径"
else:
	unAppClassPath = os.path.join(desPath,"Res/analyse_Package/tempApp/Debug-iphoneos/YppLife.app");
	
print "unAppClassPath == " + str(unAppClassPath)



#运行大图检测脚本
bigPicArr = getAllBigPic.optionBigPic(mainPbxproj,podPbxproj,bigMax)
print "bigPicArr == " + str(bigPicArr)
if bigPicArr:
	sendArr.append({'大资源': bigPicArr})


#运行重复资源脚本
repeatPicArr = getRepeatPic.optionRepeatPic(repeatResourcePodPath,repeatResourceMainPath,"")
print "repeatPicArr == " + str(repeatPicArr)
if repeatPicArr:
	sendArr.append({'重复资源': repeatPicArr})

#运行无用资源脚本
unUsePicArr = UnusedPicture.optionUnUsePic(unUsePicPath)
print "unUsePicArr == " + str(unUsePicArr)
if unUsePicArr:
	sendArr.append({'无用资源': unUsePicArr})

#运行无用类脚本
if os.path.exists(unAppClassPath):
	unUseClassArr = classunrefs.optionUnUseClass(unAppClassPath,"")
	print "unUseClassArr == " + str(unUseClassArr)
	if unUseClassArr:
		sendArr.append({'无用类': unUseClassArr})
	pass
else:
	print "无用类检测跳过..."

branchName = "比心最新代码"
if len(sys.argv) > 1:
	branchName = sys.argv[1]
	pass
	
sendOption.dingmessage(sendArr,branchName)
sendOption.emailmessage(sendArr)

