```ruby
python UnusedPicture.py 参数1
```

参数1： 要检测的文件夹（可以是工程文件夹）

如：

```ruby
 python UnusedPicture.py /Users/feijunjie/Desktop/比心/BXLife
```



注意：

如果报没有FengNiao这个命令的话，需要安装一下。

cd到FengNiao文件夹下，执行install.sh脚本先进行安装。