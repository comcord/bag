//
//  MessagesViewController.h
//  iMessage2FengNiao
//
//  Created by Ilya Bersenev on 11/05/2018.
//  Copyright © 2018 FengNiao. All rights reserved.
//

#import <Messages/Messages.h>

@interface MessagesViewController : MSMessagesAppViewController

@end
