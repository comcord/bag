//
//  ExtensionDelegate.h
//  WatchAppFengNiao Extension
//
//  Created by Ilya Bersenev on 11/05/2018.
//  Copyright © 2018 FengNiao. All rights reserved.
//

#import <WatchKit/WatchKit.h>

@interface ExtensionDelegate : NSObject <WKExtensionDelegate>

@end
