//
//  ComplicationController.h
//  WatchAppFengNiao Extension
//
//  Created by Ilya Bersenev on 11/05/2018.
//  Copyright © 2018 FengNiao. All rights reserved.
//

#import <ClockKit/ClockKit.h>

@interface ComplicationController : NSObject <CLKComplicationDataSource>

@end
