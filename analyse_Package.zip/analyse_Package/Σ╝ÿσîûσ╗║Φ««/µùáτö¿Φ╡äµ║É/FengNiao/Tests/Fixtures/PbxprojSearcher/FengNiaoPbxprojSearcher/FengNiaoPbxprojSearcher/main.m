//
//  main.m
//  FengNiaoPbxprojSearcher
//
//  Created by Ilya Bersenev on 11/05/2018.
//  Copyright © 2018 FengNiao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
