[AlertController showAlertMessage:NSLocalizedString(@"name-of-mm") confirm:confirm sender:self];
extern "C" {

}

extern const char * imageName = "image-from-mm.jpg"
[NSString stringWithCString:imageName];
