import FengNiaoKitTests

testFengNiaoKit()

