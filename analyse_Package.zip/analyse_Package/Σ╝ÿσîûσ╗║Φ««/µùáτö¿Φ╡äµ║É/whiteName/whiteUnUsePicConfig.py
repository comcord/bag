#encoding: utf-8
#coding: utf-8

mainArr = ['Vip-1/v']

bxArr = ['BXMessageImage.xcassets/bxim_redenvelope_opened.imageset','BXMessageImage.xcassets/bxim_redenvelope_failed.imageset',
         'BXMessageImage.xcassets/bxim_back_redenvelope.imageset','BXMessageImage.xcassets/bxim_cover_redenvelope.imageset',
         'BXMessageImage.xcassets/bxim_btn_rede_open.imageset','BXMessageImage.xcassets/bxim_redenvelope_opened_mask.imageset',
         'BXMessageKit/Pods/Resources/APNGs/bxim_loading_redenvelop.png','BXMessageImage.xcassets/bxim_group_upgrade_progressing.imageset',
         'BXMessageImage.xcassets/bxim_group_upgrade_finished.imageset','BXMessageImage.xcassets/bxim_group_upgrade_locked.imageset',
         'BXMessageImage.xcassets/bxim_group_upgrade_up.imageset','BXMessageImage.xcassets/bxim_group_upgrade_line.imageset',
         'BXMessageImage.xcassets/bxim_red_packet_arrow.imageset']

yrArr = []

xyzArr = ['XYZLiveCommon/Pods/Resources/images.xcassets/pic_home_top_bg.imageset','XYZLiveAnchorCenter/Pods/Resources/images.xcassets/xyz_mine_privilege.imagese',
          'XYZLiveAnchorCenter/Pods/Resources/images.xcassets/xyz_mine_wallet.imageset','XYZLiveAnchor/Pods/Resources/images.xcassets/xyz_beauty',
          'xyz_playmate/live_noncontractual_free_guide_img.imageset','xyz_playmate/live_noncontractual_click_guide_img.imageset','xyz_live_share/xyz_btn_live_share_copy.imageset',
          'xyz_live_share/xyz_share_popup_back.imageset','xyz_newAccompany/live_icon_sofa.imageset','xyz_Live/xyz_live_containerTop.imageset',
          'XYZLiveAnchor/Pods/Resources/images.xcassets/xyz_btn_begin_beauty.imageset','XYZLiveAnchorCenter/Pods/Resources/images.xcassets/bg_tag_mine_orange.imageset',
          'XYZLiveAnchorCenter/Pods/Resources/images.xcassets/bg_tag_mine_white.imageset']

orderArr = []
gameArr = []
archArr = []
selfArr = []
thirdPartArr = ['DoraemonKit/Pods']
otherArr = []


whiteConfigArr = mainArr + bxArr + yrArr + xyzArr + orderArr + gameArr + archArr + selfArr + thirdPartArr + otherArr





def getWhiteConfigArr():
	return whiteConfigArr