#encoding: utf-8
#coding: utf-8
import sys
import os
import shutil
import pdfkit
import copy
import json
currentHeader = (sys.path[0]).split('/Res/analyse_Package')[0]
projFolderName = currentHeader.split('/')[-1]
fatherPath = os.path.join(currentHeader,"Res/analyse_Package")
sys.path.append(fatherPath) 
import podConfig
import sendOption
whiteConfigPath = os.path.join(fatherPath,"优化建议/无用资源/whiteName")
sys.path.append(whiteConfigPath) 
import whiteUnUsePicConfig

class calculateHelper ():
    def GetPathSize(self,strPath):
        if not os.path.exists(strPath):
            # print "不存在" + strPath
            return 0
        if os.path.isfile(strPath):
            # print "是文件"
            return os.path.getsize(strPath)
        total_size = 0
        seen = {} 
        for dirpath, dirnames, filenames in os.walk(strPath):
            #get child directory size 
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    stat = os.stat(fp)
                except OSError:
                    continue

                try:
                    seen[stat.st_ino]
                except KeyError:
                    seen[stat.st_ino] = True
                else:
                    continue

                total_size += stat.st_size


        return total_size



#分类方法
#两个参数：1.分类选项数组(bx，yr，xyz等)，2.遍历的初始数组
def getDetailSort(output_module_map, cycleArray):
    helper = podConfig.podConfigClass()
    sortArr = helper.configDetail(output_module_map,cycleArray)
    return sortArr


def writeInTableFile(fh,pathArr,titleName,ownerName,globleNameArr):
	if not pathArr:
		return
	addPathNamer(ownerName,titleName,len(pathArr),globleNameArr)
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="5" color="blue">%s：</font>' % titleName)
	fh.write('<br>')
	fh.write('<font size="4" color="red">负责人：%s</font>' % ownerName)
	fh.write('<table border="1">')
	fh.write('<tr><th>UnUsePicPath</th><th>picSize / B</th><th>picSize / K</th><tr>')
	for pathDic in pathArr:
		eleName = list(pathDic)[0]
		podName = eleName.split('-')[0]
		eleSize = eleName.split('-')[-1]
		elePath = list(pathDic.values())[0]
		fh.write('<tr><td>%s</td><td>%s</td><td>%s</td></tr>' % (elePath, eleSize, '{:.2f}'.format(float(eleSize)/1024)))

	fh.write("</table>")


def queryArrInTableFile(fh,pathArr,titleName):
	if not pathArr:
		return
	fh.write('<br>')
	fh.write('<font size="4" color="black">%s：%s 个</font>' % (titleName, len(pathArr)))



		
def addPathNamer(nameStr,moduleStr,count,globleNameArr):
	if count > 0:
		globleNameArr.append({moduleStr:[nameStr,count]})
		pass
	pass



def optionUnUsePic(targetPath):
	print ""
	print ""
	print "*********************无用资源检测开始*********************"

	path = targetPath
	outPut = os.popen('fengniao -p %s -e localPods Res Broadcast' % path)
	print "正在统计中，检测的工程越大，时间越长，请耐心等候哦..."

	x = outPut.readlines()

	globleNameArr = []

	calculater = calculateHelper()
	contentArr = []
	mainArr = []

	splitString = projFolderName + "/Pods/"

	for line in x:
		line = line.replace("\n","")
		if line.startswith('BX-'):
			podPath = line.split('BXPath-')[-1]
			currentSize = calculater.GetPathSize(podPath)
			print line
			currentPathArr = line.split(splitString)
			if len(currentPathArr) > 1:
				#pod中的资源
				lastOne = currentPathArr[-1]
				fileKey = lastOne.split('/')[0]
				contentArr.append({str(fileKey + "-" + str(currentSize)): lastOne})
			else:
				#主工程中的资源
				mainArr.append({str("Main-" + str(currentSize)): podPath})

	print ""
	print "contentArr == " + str(contentArr)
	print ""

	print ""
	print "mainArr == " + str(mainArr)
	print ""

	whiteArr = whiteUnUsePicConfig.getWhiteConfigArr()

	print ""
	print "whiteArr == " + str(whiteArr)
	print ""

	mainTwoArr = copy.deepcopy(mainArr)
	whiteTwoArr = copy.deepcopy(whiteArr)
	for mainDic in mainTwoArr:
		value = list(mainDic.values())[0]
		whiteTwoArr = copy.deepcopy(whiteArr)
		for white in whiteTwoArr:
			if white in value:
				mainArr.remove(mainDic)
				# whiteArr.remove(white)
				break
			pass
		pass

	# print "过滤掉主工程后的 whiteArr= " + str(whiteArr)

	contentTwoArr = copy.deepcopy(contentArr)
	for contentDic in contentTwoArr:
		value = list(contentDic.values())[0]
		for white in whiteArr:
			if white in value:
				contentArr.remove(contentDic)
				break
			pass
		pass

	output_module_map = {"bx": [], "yr": [], "xyz": [], "other": [], "order": [], "arch": [], "self": [],
                         "thirdPart": [], "game": []}
	output_module_map = getDetailSort(output_module_map,contentArr)

	print ""
	print "Main:"
	print ""
	print mainArr

	print ""
	print "bx:"
	print ""
	print output_module_map["bx"]

	print ""
	print "yr:"
	print ""
	print output_module_map["yr"]

	print ""
	print "xyz:"
	print ""
	print output_module_map["xyz"]

	print ""
	print "order:"
	print ""
	print output_module_map["order"]

	print ""
	print "game:"
	print ""
	print output_module_map["game"]

	print ""
	print "arch:"
	print ""
	print output_module_map["arch"]

	print ""
	print "self:"
	print ""
	print output_module_map["self"]

	print ""
	print "thirdPart:"
	print ""
	print output_module_map["thirdPart"]

	print ""
	print "other:"
	print ""
	print output_module_map["other"]

	currentPath = os.path.join(fatherPath,"优化建议/无用资源")
	report_path = os.path.join(currentPath,"html")
	if os.path.exists(report_path):
		shutil.rmtree(report_path)

	os.mkdir(report_path)

	pod_resoureHtml_path = os.path.join(currentPath,"html/UnusedPic.html")

	fh = open(pod_resoureHtml_path, 'w')
	fh.write('<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
	fh.write('<font size="5" color="red">无用资源归类：</font>')

	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="4" color="blue">本次检测查询得到的业务组如下：</font>')
	fh.write('<br>')
	queryArrInTableFile(fh,mainArr,"主工程")
	queryArrInTableFile(fh,output_module_map["bx"],"比心BX")
	queryArrInTableFile(fh,output_module_map["yr"],"语音聊天室YR")
	queryArrInTableFile(fh,output_module_map["xyz"],"直播xyz")
	queryArrInTableFile(fh,output_module_map["order"],"陪玩order")
	queryArrInTableFile(fh,output_module_map["game"],"小游戏game")
	queryArrInTableFile(fh,output_module_map["arch"],"架构相关")
	queryArrInTableFile(fh,output_module_map["self"],"自研相关")
	queryArrInTableFile(fh,output_module_map["thirdPart"],"第三方相关")
	queryArrInTableFile(fh,output_module_map["other"],"其他")

	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="4" color="blue">详情如下：</font>')

	writeInTableFile(fh,mainArr,"主工程",'费俊杰',globleNameArr)
	writeInTableFile(fh,output_module_map["bx"],"比心BX",'费俊杰',globleNameArr)
	writeInTableFile(fh,output_module_map["yr"],"语音聊天室YR",'汪涛',globleNameArr)
	writeInTableFile(fh,output_module_map["xyz"],"直播XYZ",'刘立',globleNameArr)
	writeInTableFile(fh,output_module_map["order"],"陪玩Order",'李军灼',globleNameArr)
	writeInTableFile(fh,output_module_map["game"],"小游戏Game",'姜腾',globleNameArr)
	writeInTableFile(fh,output_module_map["arch"],"架构相关",'费俊杰',globleNameArr)
	writeInTableFile(fh,output_module_map["self"],"自研相关",'费俊杰',globleNameArr)
	writeInTableFile(fh,output_module_map["thirdPart"],"第三方相关",'费俊杰',globleNameArr)
	writeInTableFile(fh,output_module_map["other"],"其他",'费俊杰',globleNameArr)
	fh.close()

	pdfkit.from_file(pod_resoureHtml_path,os.path.join(currentPath,"html/%s" % "UnusePic.pdf"))

	print "NameArr == " + json.dumps(globleNameArr, encoding="UTF-8",ensure_ascii=False)

	print "====================无用资源检测完毕===================="
	print ""
	print ""
	return globleNameArr



if __name__ == "__main__":
	optionUnUsePic(sys.argv[1])






