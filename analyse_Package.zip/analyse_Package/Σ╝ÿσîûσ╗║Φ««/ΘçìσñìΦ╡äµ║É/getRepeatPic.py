#encoding: utf-8
#coding: utf-8
import sys
import os
import copy
import shutil
import pdfkit
import json
currentHeader = (sys.path[0]).split('/Res/analyse_Packag')[0]
projFolderName = currentHeader.split('/')[-1]
fatherPath = os.path.join(currentHeader,"Res/analyse_Package")
print "fatherPath == " + str(fatherPath)
sys.path.append(fatherPath) 
import podConfig
import sendOption

whiteConfigPath = os.path.join(fatherPath,"优化建议/重复资源/whiteName")
print "whiteConfigPath == " + str(whiteConfigPath)
sys.path.append(whiteConfigPath) 
import whiteRepicConfig


#分类方法
#两个参数：1.分类选项数组(bx，yr，xyz等)，2.遍历的初始数组
def getDetailSort(output_module_map, cycleArray):
    helper = podConfig.podConfigClass()
    sortArr = helper.configDetail(output_module_map,cycleArray)
    return sortArr



def writeInTableFile(fh,pathArr,titleName,ownerName,arrNum,caidan,globleNameArr):
	if not pathArr:
		return
	if arrNum <= 0:
		return
	addPathNamer(ownerName,titleName,arrNum,globleNameArr)
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="5" color="blue">%s：</font>' % titleName)
	fh.write('<br>')
	fh.write('<font size="4" color="red">负责人：%s</font>' % ownerName)
	
	for pathDic in pathArr:
		eleName = list(pathDic)[0]
		eleLastName = (eleName.split('-'))[-1]
		elePathArr = list(pathDic.values())[0]
		fh.write('<table border="1">')
		if caidan is "y":
			fh.write('<tr><th>负责人：</th></tr>')
			fh.write('<tr><th>进度：</th></tr>')
			fh.write('<tr><th>repeatPath</th><th>Size / K</th></tr>')
		else:
			fh.write('<tr><th>repeatPath</th><th>Size / B</th><th>Size / K</th></tr>')

		for elePath in elePathArr:
			if caidan is "y":
				fh.write('<tr><td>%s</td><td>%s</td></tr>' % (elePath, '{:.2f}'.format(float(eleLastName)/1024)))
			else:
				fh.write('<tr><td>%s</td><td>%s</td><td>%s</td></tr>' % (elePath, eleLastName, '{:.2f}'.format(float(eleLastName)/1024)))
		pass

	fh.write("</table>")


def queryArrInTableFile(fh,pathArr,titleName):
    if not pathArr:
        return
    fh.write('<br>')
    fh.write('<font size="4" color="black">%s：%s 组</font>' % (titleName, len(pathArr)))


def addPathNamer(nameStr,moduleStr,count,globleNameArr):
	if count > 0:
		globleNameArr.append({moduleStr:[nameStr,count]})
		pass
	pass


def optionRepeatPic(podPath,mainPath,caidan):
	print ""
	print ""
	print "******************重复资源检测开始*********************"

	output = os.popen('fdupes -Sr %s %s' % (podPath, mainPath))
	print "22222"

	beginArr = []
	globleNameArr = []
	whiteArr = whiteRepicConfig.getWhiteConfigArr()

	print "白名单："
	print whiteArr
	print ""

	for temp in output.readlines():
		temp = temp.strip()
		if temp.endswith('.hpp') or temp.endswith('/LICENSE') or temp.endswith('/Contents.json') or temp.endswith('/README.md') or temp.endswith('.xcconfig') or temp.endswith('.pch'):
			continue
		else:
			#print temp
			beginArr.append(temp)
		pass

	currentArr = []
	key = ""
	lastArr = []

	splitString = "/" + projFolderName + "/Pods/"

	for x in beginArr:
		if 'bytes each' in x:
			key = x.strip()
		else:
			if x.strip():
				#不为空
				a = x.split(splitString)
				currentArr.append(a[-1])
			else:
				#当前行为空行,执行加入或者不加操作
				if currentArr:
					lastArr.append({key: currentArr})
					key = ""
					currentArr = []
				else:
					#不加
					key = ""
					currentArr = []
					pass
		pass

	# print lastArr

	newArr = []

	for eleDic in lastArr:
		eleKeys = list(eleDic)[0]
		eleValues = list(eleDic.values())[0]
		firstValue = eleValues[0]
		# if firstValue.endswith(".pdf") or firstValue.endswith(".strings") or firstValue.endswith(".plist"):
		# 	continue
		podsName = (firstValue.split('/'))[0]
		keysName = (eleKeys.split(' '))[0]
		if int(keysName) < 1024*10:
			#过滤掉小于10k的资源
			continue
		lastKeyName = podsName + "-" + keysName
		newArr.append({lastKeyName: eleValues})
		pass

	# print newArr
	# print keysArr
	print "过滤前的所有数组："
	print newArr
	print ""

	print "过滤前的白名单："
	print whiteArr
	print ""


	newTwoArr=copy.deepcopy(newArr)

	for newElementDic in newTwoArr:
		newElementValueArr = list(newElementDic.values())[0]
		for valueElement in newElementValueArr:
			last = False
			for needMoveEle in whiteArr:
				if needMoveEle in valueElement:
					newArr.remove(newElementDic)
					last = True
					break
			if last:
				break
		pass

	print "过滤后的白名单："
	print whiteArr
	print ""

	print "过滤后的所有数组："
	print newArr
	print ""

	output_module_map = {"bx": [], "sq": [], "yr": [], "xyz": [], "other": [], "order": [], "arch": [], "self": [],
                         "thirdPart": [], "game": []}
	output_module_map = getDetailSort(output_module_map,newArr) 

	#other中还包含了main的，需要拎出来
	mainArr = []
	otherArr = copy.deepcopy(output_module_map["other"])
	for otherItem in output_module_map["other"]:
		otherItemKey = list(otherItem)[0]
		otherItemValue = list(otherItem.values())[0]
		otherPodsName = (otherItemKey.split('-'))[0]
		if otherPodsName:
			pass
		else:
			mainArr.append(otherItem)
			otherArr.remove(otherItem)

	output_module_map["other"] = otherArr

	print "main:"
	print ""
	print mainArr
	print ""

	print "bx:"
	print ""
	print output_module_map["bx"]
	print ""

	print "sq:"
	print ""
	print output_module_map["sq"]
	print ""

	print "yr:"
	print ""
	print output_module_map["yr"]
	print ""

	print "xyz:"
	print ""
	print output_module_map["xyz"]
	print ""

	print "order:"
	print ""
	print output_module_map["order"]
	print ""

	print "game:"
	print ""
	print output_module_map["game"]
	print ""

	print "arch:"
	print ""
	print output_module_map["arch"]
	print ""

	print "self:"
	print ""
	print output_module_map["self"]
	print ""

	print "thirdPart:"
	print ""
	print output_module_map["thirdPart"]
	print ""

	print "other:"
	print ""
	print output_module_map["other"]
	print ""

	currentPath = os.path.join(fatherPath,"优化建议/重复资源")
	report_path = os.path.join(currentPath,"html")
	if os.path.exists(report_path):
		shutil.rmtree(report_path)

	os.mkdir(report_path)
	pod_resoureHtml_path = os.path.join(currentPath,"html/repeatPic.html")

	fh = open(pod_resoureHtml_path, 'w')
	fh.write('<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
	fh.write('<font size="5" color="red">重复资源归类：</font>')

	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="4" color="blue">本次检测查询得到的业务组如下：</font>')
	fh.write('<br>')

	queryArrInTableFile(fh,mainArr,"主工程")
	queryArrInTableFile(fh,output_module_map["bx"],"比心BX")
	queryArrInTableFile(fh,output_module_map["sq"],"社区Sq")
	queryArrInTableFile(fh,output_module_map["yr"],"语音聊天室YR")
	queryArrInTableFile(fh,output_module_map["xyz"],"直播XYZ")
	queryArrInTableFile(fh,output_module_map["order"],"陪玩Order")
	queryArrInTableFile(fh,output_module_map["game"],"小游戏Game")
	queryArrInTableFile(fh,output_module_map["arch"],"架构相关")
	queryArrInTableFile(fh,output_module_map["self"],"自研相关")
	queryArrInTableFile(fh,output_module_map["thirdPart"],"第三方相关")
	queryArrInTableFile(fh,output_module_map["other"],"其他")

	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="4" color="blue">详情如下：</font>')


	writeInTableFile(fh,mainArr,"主工程",'费俊杰',len(mainArr),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["bx"],"比心BX",'费俊杰',len(output_module_map["bx"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["bx"],"社区Sq",'王鹏',len(output_module_map["bx"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["yr"],"语音聊天室YR",'汪涛',len(output_module_map["yr"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["xyz"],"直播XYZ",'刘立',len(output_module_map["xyz"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["order"],"陪玩Order",'李军灼',len(output_module_map["order"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["game"],"小游戏Game",'姜腾',len(output_module_map["game"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["arch"],"架构相关",'费俊杰',len(output_module_map["arch"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["self"],"自研相关",'费俊杰',len(output_module_map["self"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["thirdPart"],"第三方相关",'费俊杰',len(output_module_map["thirdPart"]),caidan,globleNameArr)
	writeInTableFile(fh,output_module_map["other"],"其他",'费俊杰',len(output_module_map["other"]),caidan,globleNameArr)
	fh.close()
	pdfkit.from_file(pod_resoureHtml_path,os.path.join(currentPath,"html/%s" % "repeatPic.pdf"))

	print "NameArr == " + json.dumps(globleNameArr, encoding="UTF-8",ensure_ascii=False)
	print "====================重复资源检测完毕===================="
	print ""
	print ""
	return globleNameArr



			
			
		


if __name__ == "__main__":
	if len(sys.argv) < 2:
		print "缺少参数，参数请传全"
		print "'请输入要检测工程的Pods目录'"
		exit(0)

	pathOne = sys.argv[1]
	pathTwo = sys.argv[2]
	pathThree = ""
	if len(sys.argv) > 3:
		pathThree = sys.argv[3:][0]
	print pathOne
	print pathTwo
	print pathThree
	print len(sys.argv)
	optionRepeatPic(pathOne,pathTwo,pathThree)

