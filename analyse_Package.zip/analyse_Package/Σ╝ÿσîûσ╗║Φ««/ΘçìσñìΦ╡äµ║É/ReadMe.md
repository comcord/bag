### 使用须知：

#### 1.执行脚本

```
 python /Users/feijunjie/Desktop/包体报表相关/重复资源/getRepeatPic.py 参数1 参数2
```

参数1：工程中pods文件夹。

参数2：工程中主工程资源文件夹。

示例：

```ruby
python /Users/feijunjie/Desktop/包体报表相关/重复资源/getRepeatPic.py /Users/feijunjie/Desktop/比心/BXLife/Pods /Users/feijunjie/Desktop/比心/BXLife/YppLife
```

检测这两个文件夹中共同的重复资源





#### 2.环境

使用前保证系统可以执行Fdupes命令，没有的话必须得下载插件Fdupes，mac上用：

```ruby
brew install Fdupes
```

不行的话，前面加个sudo









#### 3.彩蛋

跟第三个参数y，可以得到登记列表样式。