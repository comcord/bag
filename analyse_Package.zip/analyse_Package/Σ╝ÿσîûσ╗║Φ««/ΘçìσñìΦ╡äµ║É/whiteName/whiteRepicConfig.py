#encoding: utf-8
#coding: utf-8

mainArr = []
bxArr = []
sqArr = []
yrArr = []
xyzArr = []
orderArr = []
gameArr = []
archArr = []
selfArr = []
thirdArr = ['UMCCommon/Pods','WBCommonService/Pods','WBCloudReflectionFaceVerify/Pods','WBOCRService/Pods',
            'MercuryService/Pods/Frameworks/boost.framework']
otherArr = []


whiteConfigArr = mainArr + bxArr + yrArr + xyzArr + orderArr + gameArr + thirdArr + selfArr + archArr + otherArr + sqArr





def getWhiteConfigArr():
	return whiteConfigArr