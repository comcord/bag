#encoding: utf-8
#coding: utf-8
import MainProjectHelper
import os
import copy


class calculateHelper ():
    def GetPathSize(self,strPath):
        if not os.path.exists(strPath):
            # print "不存在" + strPath
            return 0
        if os.path.isfile(strPath):
            # print "是文件"
            return os.path.getsize(strPath)
        total_size = 0
        seen = {} 
        for dirpath, dirnames, filenames in os.walk(strPath):
            #get child directory size 
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    stat = os.stat(fp)
                except OSError:
                    continue

                try:
                    seen[stat.st_ino]
                except KeyError:
                    seen[stat.st_ino] = True
                else:
                    continue

                total_size += stat.st_size


        return total_size


    def GetAllPicPath(self,strPath):
        picArr = []
        if not os.path.exists(strPath):
            # print "不存在" + strPath
            return []
        if os.path.isfile(strPath):
            # print "是文件"
            if self.judgePic(strPath):
                return [strPath]
            else:
                return []
        total_size = 0
        seen = {}
        for dirpath, dirnames, filenames in os.walk(strPath):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    stat = os.stat(fp)
                except OSError:
                    continue

                try:
                    seen[stat.st_ino]
                except KeyError:
                    seen[stat.st_ino] = True
                else:
                    continue

                if self.judgePic(fp):
                    picArr.append(fp)

        return picArr



    def judgePic(self,strPath):
        urlPath = strPath.strip()
        if urlPath.endswith('.png') or urlPath.endswith('.apng') or urlPath.endswith('.svg') or urlPath.endswith('.svga') or urlPath.endswith('.mp4') or urlPath.endswith('.mp3') or urlPath.endswith('.ttf')  or urlPath.endswith('.m4a') or urlPath.endswith('.wav') or urlPath.endswith('.webp') or urlPath.endswith('.aac'):
            return True
        else:
            return False



# helper = PBXProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/localPods/BXSetting/Example/Pods/Pods.xcodeproj/project.pbxproj")
# helper = PBXProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/localPods/BXAboutMe/Example/BXAboutMe.xcodeproj/project.pbxproj")
# helper = MainProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/Pods/Pods.xcodeproj/project.pbxproj")




def resourceOutArr(path,limitSize):
    helper = MainProjectHelper.PBXProjectHelper(path)
    pathArr = helper.project.inputPathArr()
    # print pathArr
    # print "外面========"
    # print pathArr

    calculater = calculateHelper()

    # lastArr = []
    sumSize = 0
    for elements in pathArr:
        currentSize=calculater.GetPathSize(elements)
        sumSize = sumSize + currentSize


    print "========"
    print ""
    detail_module_map = {"resource": [], "config": [], "other": [], "code": []}

    allCycleArr=copy.deepcopy(pathArr)

    for urlPath in pathArr:
        urlPath = urlPath.strip()
        if urlPath.endswith('.xcassets') or urlPath.endswith('.png') or urlPath.endswith('.apng') or urlPath.endswith('.svg') or urlPath.endswith('.svga') or urlPath.endswith('.mp4') or urlPath.endswith('.mp3') or urlPath.endswith('.ttf') or urlPath.endswith('.bundle') or urlPath.endswith('.m4a') or urlPath.endswith('.wav') or urlPath.endswith('.webp') or urlPath.endswith('.aac'):
            if urlPath.endswith('doricprejs.bundle'):
                detail_module_map["config"].append(urlPath)
            else:
                detail_module_map["resource"].append(urlPath)
        else:
            if urlPath.endswith('.js') or urlPath.endswith('.xml') or urlPath.endswith('.json') or urlPath.endswith('.plist') or urlPath.endswith('.otf') or urlPath.endswith('.zip') or urlPath.endswith('.lic') or urlPath.endswith('.proto') or urlPath.endswith('.tflite') or urlPath.endswith('.html'):
                detail_module_map["config"].append(urlPath)
            else:
                if urlPath.endswith('.h') or urlPath.endswith('.m') or urlPath.endswith('.storyboard'):
                    detail_module_map["code"].append(urlPath)
                else:
                    detail_module_map["other"].append(urlPath)
        

    
    #
    bigPicArr = []
    limitSize = int(limitSize)
    if limitSize <= 50:
        limitSize = 50
    bigSize = (limitSize * 1024)
    for urlPath in detail_module_map["resource"]:
        urlPath = urlPath.strip()
        if urlPath.endswith('.xcassets') or urlPath.endswith('.bundle'):
            setsArr = calculater.GetAllPicPath(urlPath)
            for setsElements in setsArr:
                setsSize = calculater.GetPathSize(setsElements)
                if setsSize > bigSize:
                    bigPicArr.append(setsElements)
        else:
            currentSize = calculater.GetPathSize(urlPath)
            if currentSize > bigSize:
                bigPicArr.append(urlPath)

    
    # print "dddddd"
    # print bigPicArr
    # print "ssssss"

    return bigPicArr


    # # print "resource:"
    # # print detail_module_map["resource"]
    # # print ""

    # # print ""
    # # print "config:"
    # # print detail_module_map["config"]

    # # print ""
    # # print "other:"
    # # print detail_module_map["other"]

    # resourceSize = 0
    # for paths in detail_module_map["resource"]:
    #     resourceSize = resourceSize + calculater.GetPathSize(paths)

    # # print "resource: " + str(resourceSize)

    # configSize = 0
    # for paths in detail_module_map["config"]:
    #     configSize = configSize + calculater.GetPathSize(paths)

    # # print "config: " + str(configSize)

    # codeSize = 0
    # for paths in detail_module_map["code"]:
    #     codeSize = codeSize + calculater.GetPathSize(paths)

    # # print "code: " + str(codeSize)

    # otherSize = 0
    # for paths in detail_module_map["other"]:
    #     otherSize = otherSize + calculater.GetPathSize(paths)

    # # print "other: " + str(otherSize)

    # detailSizeDic = {"resource": resourceSize, "config": configSize, "other": otherSize, "code": codeSize}

    # return {"sumSize": sumSize, "detail_resource_dic": detailSizeDic}


if __name__ == "__main__":
    resourceOutArr("/Users/feijunjie/Desktop/比心/BXLife/YppLife.xcodeproj/project.pbxproj")







