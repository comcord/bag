#encoding: utf-8
#coding: utf-8

import getMainBigPic
import getPodBigPic
import os
import shutil
import sys
import pdfkit
import requests
import json
import copy

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

currentHeader = (sys.path[0]).split('Res/analyse_Package')[0]
fatherPath = os.path.join(currentHeader,"Res/analyse_Package")
sys.path.append(fatherPath) 
import podConfig
import sendOption
whiteConfigPath = os.path.join(fatherPath,"优化建议/获取工程大图/whiteName")
print "whiteConfigPath == " + str(whiteConfigPath)
sys.path.append(whiteConfigPath)
import whiteBigConfig


#分类方法
#两个参数：1.分类选项数组(bx，yr，xyz等)，2.遍历的初始数组
def getDetailSort(output_module_map, cycleArray):
    helper = podConfig.podConfigClass()
    sortArr = helper.configDetail(output_module_map,cycleArray)
    return sortArr



def writeInTableFile(fh,pathArr,titleName,ownerName,arrNum,globleNameArr):
	if not pathArr:
		return
	
	if arrNum <= 0:
		return
	addPathNamer(ownerName,titleName,arrNum,globleNameArr)
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="5" color="blue">%s</font>' % titleName)
	fh.write('<br>')
	fh.write('<font size="4" color="red">负责人：%s</font>' % ownerName)
	fh.write('<table border="1">')
	fh.write('<tr><th>picPath</th><th>picSize / B</th><th>picSize / K</th><tr>')
	for pathDic in pathArr:
		eleName = list(pathDic)[0]
		elePathArr = list(pathDic.values())[0]
		for elePath in elePathArr:
			currentSize = os.path.getsize(elePath)
			fh.write('<tr><td>%s</td><td>%s</td><td>%s</td></tr>' % (elePath, currentSize, '{:.2f}'.format(float(currentSize)/1024)))
		pass

	fh.write("</table>")


def queryArrInTableFile(fh,pathArr,titleName):
    if not pathArr:
        return 0
    arrNum = 0
    for pathDic in pathArr:
    	if isinstance(pathDic,str):
    		arrNum = len(pathArr)
    		break
    	else:
    		eleArr = list(pathDic.values())[0]
    		arrNum = arrNum + len(eleArr)
    	pass
    if arrNum <= 0:
    	return 0
    fh.write('<br>')
    fh.write('<font size="4" color="black">%s：%s 个</font>' % (titleName, arrNum))
    return arrNum



def addPathNamer(nameStr,moduleStr,count,globleNameArr):
	if count > 0:
		globleNameArr.append({moduleStr:[nameStr,count]})
		pass
	# if nameStr not in globleNameArr:
	# 	globleNameArr.append(nameStr)
	pass



def optionBigPic(mainPbProj,podPbProj,bigMax):
	print ""
	print ""
	print "*********************大图检测开始*********************"
	mainArr = getMainBigPic.resourceOutArr(mainPbProj,bigMax)
	podsArr = getPodBigPic.resourceOutArr(podPbProj,bigMax)
	whiteArr = whiteBigConfig.getWhiteConfigArr()

	print "mainArr:"
	print mainArr
	print ""

	print "podsArr:"
	print podsArr
	print ""

	print "11111111111======"
	print "白名单："
	print whiteArr
	print ""

	mainTwoArr=copy.deepcopy(mainArr)
	whiteTwoArr=copy.deepcopy(whiteArr)

	for needMoveEle in whiteTwoArr:
		for mainElement in mainTwoArr:
			if needMoveEle in mainElement:
				mainArr.remove(mainElement)
				# whiteArr.remove(needMoveEle)
				break
			pass

	# print "第一轮过滤后的白名单："
	# print whiteArr
	# print ""

	for podsDic in podsArr:
		podEleName = list(podsDic)[0]
		podsEleArr = list(podsDic.values())[0]
		podsEleTwoArr = copy.deepcopy(podsEleArr)
		whiteTwoArr=copy.deepcopy(whiteArr)
		# print "遍历前，whiteTwoArr == " + str(whiteTwoArr)
		# print "遍历前，podsEleTwoArr == " + str(podsEleTwoArr)
		# print "遍历前，podsArr == " + str(podsArr)
		for whiteElement in whiteTwoArr:
			#数组可能减少，需要重新赋值，要不然会有元素被重复遍历
			podsEleArr = copy.deepcopy(podsEleTwoArr)
			for podEleArrElement in podsEleArr:
				if whiteElement in podEleArrElement:
					whiteArr.remove(whiteElement)
					podsEleTwoArr.remove(podEleArrElement)
					# print "在白名单内：" + podEleArrElement
					break
				pass
			pass
		# print "遍历完白名单一轮后，当前podsEleTwoArr：" + str(podsEleTwoArr)
		podsDic[podEleName]=podsEleTwoArr
		pass

	print "过滤后的mainArr:"
	print mainArr
	print ""

	print "过滤后的podsArr:"
	print podsArr
	print ""

	globleNameArr = []

	output_module_map = {"bx": [], "sq": [], "yr": [], "xyz": [], "other": [], "order": [], "arch": [], "self": [],
                         "thirdPart": [], "game": []}
	output_module_map = getDetailSort(output_module_map,podsArr)

	print "bx:"
	print ""
	print output_module_map["bx"]

	print "sq:"
	print ""
	print output_module_map["sq"]

	print "yr:"
	print ""
	print output_module_map["yr"]

	print "xyz:"
	print ""
	print output_module_map["xyz"]

	print "order:"
	print ""
	print output_module_map["order"]

	print "game:"
	print ""
	print output_module_map["game"]

	print "arch:"
	print ""
	print output_module_map["arch"]

	print "self:"
	print ""
	print output_module_map["self"]

	print "thirdPart:"
	print ""
	print output_module_map["thirdPart"]

	print "other:"
	print ""
	print output_module_map["other"]

	currentPath = os.path.join(fatherPath,"优化建议/获取工程大图")
	report_path = os.path.join(currentPath,"html")
	if os.path.exists(report_path):
		shutil.rmtree(report_path)
	os.mkdir(report_path)

	pod_resoureHtml_path = os.path.join(currentPath,"html/bigPic.html")

	limitSize = int(bigMax)
	if limitSize <= 50:
		limitSize = 50

	fh = open(pod_resoureHtml_path, 'w')
	fh.write('<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
	fh.write('<font size="5" color="red">大小超过%sK的图片归类：</font>' % limitSize)

	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="4" color="blue">本次检测查询得到的业务组如下：</font>')
	fh.write('<br>')

	mainNum = queryArrInTableFile(fh,mainArr,"主工程")
	bxNum = queryArrInTableFile(fh,output_module_map["bx"],"比心BX")
	sqNum = queryArrInTableFile(fh,output_module_map["sq"],"社区Sq")
	yrNum = queryArrInTableFile(fh,output_module_map["yr"],"语音聊天室YR")
	xyzNum = queryArrInTableFile(fh,output_module_map["xyz"],"直播XYZ")
	orderNum = queryArrInTableFile(fh,output_module_map["order"],"陪玩Order")
	gameNum = queryArrInTableFile(fh,output_module_map["game"],"小游戏Game")
	archNum = queryArrInTableFile(fh,output_module_map["arch"],"架构相关")
	selfNum = queryArrInTableFile(fh,output_module_map["self"],"自研相关")
	thirdNum = queryArrInTableFile(fh,output_module_map["thirdPart"],"第三方相关")
	otherNum = queryArrInTableFile(fh,output_module_map["other"],"其他")

	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="4" color="blue">详情如下：</font>')

	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')

	if mainNum > 0:
		fh.write('<font size="5" color="blue">主工程</font>')
		fh.write('<br>')
		fh.write('<font size="4" color="red">负责人：费俊杰</font>')
		fh.write('<table border="1">')
		fh.write('<tr><th>picPath</th><th>picSize / B</th><th>picSize / K</th><tr>')
		addPathNamer("费俊杰","主工程",mainNum,globleNameArr)
		for mainName in mainArr:
			currentSize = os.path.getsize(mainName)
			fh.write('<tr><td>%s</td><td>%s</td><td>%s</td></tr>' % (mainName, currentSize, '{:.2f}'.format(float(currentSize)/1024)))
			pass
		fh.write("</table>")
		pass

	writeInTableFile(fh,output_module_map["bx"],"比心BX","费俊杰",bxNum,globleNameArr)
	writeInTableFile(fh,output_module_map["sq"],"社区Sq","王鹏",sqNum,globleNameArr)
	writeInTableFile(fh,output_module_map["yr"],"语音聊天室YR","汪涛",yrNum,globleNameArr)
	writeInTableFile(fh,output_module_map["xyz"],"直播XYZ","刘立",xyzNum,globleNameArr)
	writeInTableFile(fh,output_module_map["order"],"陪玩Order","李军灼",orderNum,globleNameArr)
	writeInTableFile(fh,output_module_map["game"],"小游戏Game","姜腾",gameNum,globleNameArr)
	writeInTableFile(fh,output_module_map["arch"],"架构相关","费俊杰",archNum,globleNameArr)
	writeInTableFile(fh,output_module_map["self"],"自研相关","费俊杰",selfNum,globleNameArr)
	writeInTableFile(fh,output_module_map["thirdPart"],"第三方相关","费俊杰",thirdNum,globleNameArr)
	writeInTableFile(fh,output_module_map["other"],"其他","费俊杰",otherNum,globleNameArr)
	fh.close()
	pdfkit.from_file(pod_resoureHtml_path,os.path.join(currentPath,"html/%s" % "bigPic.pdf"))

	print "NameArr == " + json.dumps(globleNameArr, encoding="UTF-8",ensure_ascii=False)

	print "====================大图检测完毕===================="
	print ""
	print ""
	return globleNameArr



if __name__ == "__main__":
	if len(sys.argv) < 4:
		print "缺少参数，参数请传全"
		print "1.主工程project.pbxproj文件； 2.pod工程project.pbxproj文件； 3.图片大小，小于50默认为50 (单位k)"
		exit(0)

	print "junjie123"
	optionBigPic(sys.argv[1],sys.argv[2],sys.argv[3])







