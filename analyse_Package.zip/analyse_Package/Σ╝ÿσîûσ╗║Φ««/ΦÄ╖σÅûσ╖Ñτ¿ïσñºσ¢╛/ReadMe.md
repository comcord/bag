```ruby
python getAllBigPic.py 参数1 参数2 参数3
```

参数1：主工程project.pbxproj文件

参数2：pod工程project.pbxproj文件

参数3：检测图片大小，小于50默认为50



示例：

```ruby
 python /Users/feijunjie/Desktop/包体报表相关/获取工程大图/getAllBigPic.py /Users/feijunjie/Desktop/比心/BXLife/YppLife.xcodeproj/project.pbxproj /Users/feijunjie/Desktop/比心/BXLife/Pods/Pods.xcodeproj/project.pbxproj 200
```

