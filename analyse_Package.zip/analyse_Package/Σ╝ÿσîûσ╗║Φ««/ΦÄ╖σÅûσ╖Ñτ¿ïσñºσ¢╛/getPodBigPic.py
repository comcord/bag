#encoding: utf-8
#coding: utf-8
import PBXProjectHelper
import os
import copy


class calculateHelper ():
    def GetPathSize(self,strPath):
        if not os.path.exists(strPath):
            # print "不存在" + strPath
            return 0
        if os.path.isfile(strPath):
            # print "是文件"
            return os.path.getsize(strPath)
        total_size = 0
        seen = {} 
        # print "看来是文件夹"
        for dirpath, dirnames, filenames in os.walk(strPath):
            #get child directory size 
            # print filenames
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    stat = os.stat(fp)
                except OSError:
                    continue

                try:
                    seen[stat.st_ino]
                except KeyError:
                    seen[stat.st_ino] = True
                else:
                    continue

                total_size += stat.st_size



        return total_size


    def GetAllPicPath(self,strPath):
        picArr = []
        if not os.path.exists(strPath):
            # print "不存在" + strPath
            return []
        if os.path.isfile(strPath):
            # print "是文件"
            if self.judgePic(strPath):
                return [strPath]
            else:
                return []
        total_size = 0
        seen = {}
        for dirpath, dirnames, filenames in os.walk(strPath):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    stat = os.stat(fp)
                except OSError:
                    continue

                try:
                    seen[stat.st_ino]
                except KeyError:
                    seen[stat.st_ino] = True
                else:
                    continue

                if self.judgePic(fp):
                    picArr.append(fp)

        return picArr



    def judgePic(self,strPath):
        urlPath = strPath.strip()
        if urlPath.endswith('.png') or urlPath.endswith('.apng') or urlPath.endswith('.svg') or urlPath.endswith('.svga') or urlPath.endswith('.mp4') or urlPath.endswith('.mp3') or urlPath.endswith('.ttf')  or urlPath.endswith('.m4a') or urlPath.endswith('.wav') or urlPath.endswith('.webp') or urlPath.endswith('.aac'):
            return True
        else:
            return False



# helper = PBXProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/localPods/BXSetting/Example/Pods/Pods.xcodeproj/project.pbxproj")
# helper = PBXProjectHelper.PBXProjectHelper("/Users/feijunjie/Desktop/比心/BXLife/localPods/BXAboutMe/Example/BXAboutMe.xcodeproj/project.pbxproj")


#遍历数组，计算出数组中每个组件的大小，返回数组
def getSumSize(list_map):
    lastArr = []
    calculater = calculateHelper()
    for eleDic in list_map:
        currenteleArrSize = 0
        podKey = list(eleDic)[0]
        podArr = list(eleDic.values())[0]
        for elements in podArr:
            currenteleArrSize = currenteleArrSize + calculater.GetPathSize(elements)
        lastArr.append({podKey: currenteleArrSize})
    return lastArr

def resourceOutArr(path,limitSize):
    helper = PBXProjectHelper.PBXProjectHelper(path)
    # print "准备输出"
    # pathArr = helper.project.inputPathArr()
    # print pathArr
    # print "外面========"
    # print pathArr
    pathDic = helper.project.inputDoubleArr()
    frameworkArr=pathDic.setdefault("frameWork","")
    pathArr=pathDic.setdefault("podName","")
    # print frameworkArr
    # print "jun00000"
    # print pathArr
    # print "pppppp"


    # print ""

    calculater = calculateHelper()

    lastArr = []
    allPathArr = []

    bigPicArr = []
    limitSize = int(limitSize)
    if limitSize < 50:
        limitSize = 50
    bigSize = (limitSize * 1024)
    for eleDic in pathArr:
        bigPodsArr = []
        podKey = list(eleDic)[0]
        podArr = list(eleDic.values())[0]
        for urlPath in podArr:
            urlPath = urlPath.strip()
            if urlPath.endswith('.xcassets') or urlPath.endswith('.png') or urlPath.endswith('.apng') or urlPath.endswith('.svg') or urlPath.endswith('.svga') or urlPath.endswith('.mp4') or urlPath.endswith('.mp3') or urlPath.endswith('.ttf') or urlPath.endswith('.bundle') or urlPath.endswith('.m4a') or urlPath.endswith('.wav') or urlPath.endswith('.webp') or urlPath.endswith('.aac'):
                if urlPath.endswith('.xcassets') or urlPath.endswith('.bundle'):
                    setsArr = calculater.GetAllPicPath(urlPath)
                    for setsElements in setsArr:
                        setsSize = calculater.GetPathSize(setsElements)
                        if setsSize > bigSize:
                            bigPodsArr.append(setsElements)
                            pass
                else:
                    currentSize = calculater.GetPathSize(urlPath)
                    if currentSize > bigSize:
                        bigPodsArr.append(urlPath)

        if bigPodsArr:
            bigPicArr.append({podKey: bigPodsArr})
        pass


    # print "jjjjjjjjjj"
    # print bigPicArr
    # print "tttttttt"


    # print "开始了"
    # pp = '/Users/feijunjie/Desktop/\xe6\xaf\x94\xe5\xbf\x83/BXLife/Pods/ChatRoom/Pods/Resources/Resources/ChatRoomResource.bundle'
    # tttt = calculater.GetAllPicPath(pp)
    # print tttt
    # print "结束了"






    return bigPicArr

    # #===============统计各个组件的大小====================
    # for eleDic in pathArr:
    #     currenteleArrSize = 0
    #     for key in eleDic:
    #         eleArr = eleDic[key]
    #         for elements in eleArr:
    #             currentSize = calculater.GetPathSize(elements)
    #             currenteleArrSize = currenteleArrSize + calculater.GetPathSize(elements)
    #             allPathArr.append(elements)
    #     lastArr.append({key: currenteleArrSize})
    


    # # print allPathArr

    # print ""





    # #=====================pod库中resource按照资源划分，每种资源下对应的总大小================
    # detail_module_map = {"resource": [], "config": [], "other": []}

    # allCycleArr=copy.deepcopy(allPathArr)
    # for urlPath in allPathArr:
    #     urlPath = urlPath.strip()
    #     if urlPath.endswith('.xcassets') or urlPath.endswith('.png') or urlPath.endswith('.apng') or urlPath.endswith('.svg') or urlPath.endswith('.svga') or urlPath.endswith('.mp4') or urlPath.endswith('.mp3') or urlPath.endswith('.ttf') or urlPath.endswith('.bundle') or urlPath.endswith('.m4a') or urlPath.endswith('.wav') or urlPath.endswith('.webp') or urlPath.endswith('.aac'):
    #         detail_module_map["resource"].append(urlPath)
    #     else:
    #         if urlPath.endswith('.js') or urlPath.endswith('.xml') or urlPath.endswith('.json') or urlPath.endswith('.plist') or urlPath.endswith('.otf') or urlPath.endswith('.zip') or urlPath.endswith('.lic') or urlPath.endswith('.proto') or urlPath.endswith('.tflite') or urlPath.endswith('.html'):
    #             detail_module_map["config"].append(urlPath)
    #         else:
    #             detail_module_map["other"].append(urlPath)
            

    # # print "ssssss"
    # # print detail_module_map["resource"]
    # # print "rrrrrrrr"

    # # for eleDic in detail_module_map["resource"]:
    # #     bigPodsArr = []
    # #     podKey = list(eleDic)[0]
    # #     podArr = list(eleDic.values())[0]
    # #     for elements in podArr:
    # #         currentSize = calculater.GetPathSize(elements)
    # #         if currentSize > (200 * 1024):
    # #             bigPodsArr.append(elements)
    # #             pass
    # #         pass
    # #     if bigPodsArr:
    # #         bigPicArr.append({podKey: bigPodsArr})
    # #     pass


    # # print "jjjjjjjjjj"




    # resourceSize = 0
    # for paths in detail_module_map["resource"]:
    #     resourceSize = resourceSize + calculater.GetPathSize(paths)

    # # print "resource: " + str(resourceSize)


    # configSize = 0
    # for paths in detail_module_map["config"]:
    #     configSize = configSize + calculater.GetPathSize(paths)

    # # print "config: " + str(configSize)

    # otherSize = 0
    # for paths in detail_module_map["other"]:
    #     otherSize = otherSize + calculater.GetPathSize(paths)

    # # print "other: " + str(otherSize)

    # detailSizeDic = {"resource": resourceSize, "config": configSize, "other": otherSize}



    

    # #================pod库中resource按照资源划分，每种资源下对应pod的数组=============

    # pod_list_map = {"resource": [], "config": [], "other": []}
    # for pathDic in pathArr:
    #     podKey = list(pathDic)[0]
    #     podArr = list(pathDic.values())[0]
    #     resourceArr = []
    #     configArr = []
    #     otherArr = []
    #     for urlPath in podArr:
    #         urlPath = urlPath.strip()
    #         if urlPath.endswith('.xcassets') or urlPath.endswith('.png') or urlPath.endswith('.apng') or urlPath.endswith('.svg') or urlPath.endswith('.svga') or urlPath.endswith('.mp4') or urlPath.endswith('.mp3') or urlPath.endswith('.ttf') or urlPath.endswith('.bundle') or urlPath.endswith('.m4a') or urlPath.endswith('.wav') or urlPath.endswith('.webp') or urlPath.endswith('.aac'):
    #             resourceArr.append(urlPath)
    #         else:
    #             if urlPath.endswith('.js') or urlPath.endswith('.xml') or urlPath.endswith('.json') or urlPath.endswith('.plist') or urlPath.endswith('.otf') or urlPath.endswith('.zip') or urlPath.endswith('.lic') or urlPath.endswith('.proto') or urlPath.endswith('.tflite') or urlPath.endswith('.html'):
    #                 configArr.append(urlPath)
    #             else:
    #                 otherArr.append(urlPath)
    #     if resourceArr:
    #         pod_list_map["resource"].append({podKey: resourceArr})
    #     if configArr:
    #         pod_list_map["config"].append({podKey: configArr})
    #     if otherArr:
    #         pod_list_map["other"].append({podKey: otherArr})


    # pod_list_map["resource"] = getSumSize(pod_list_map["resource"])
    # pod_list_map["config"] = getSumSize(pod_list_map["config"])
    # pod_list_map["other"] = getSumSize(pod_list_map["other"])


    # sortResourceDic = {"resource": pod_list_map["resource"], "config": pod_list_map["config"], "other": pod_list_map["other"]  }
    # # print "aaaaaaaaa======================aaaa"
    # # print "resource:"
    # # print pod_list_map["resource"]
    # # print ""
    # # print "config:"
    # # print pod_list_map["config"]
    # # print ""
    # # print "other:"
    # # print pod_list_map["other"]
    # # print ""
    # # print "aaaaaaaaa======================aaaa"


    # return {"frameWork": frameworkArr, "podName": lastArr, "detailSize_resource_dic": detailSizeDic, "detail_List_dic": sortResourceDic}




if __name__ == "__main__":
    resourceOutArr("/Users/feijunjie/Desktop/比心/BXLife/Pods/Pods.xcodeproj/project.pbxproj")
