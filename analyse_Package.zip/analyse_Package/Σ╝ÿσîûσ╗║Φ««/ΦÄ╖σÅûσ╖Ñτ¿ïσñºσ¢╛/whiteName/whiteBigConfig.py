#encoding: utf-8
#coding: utf-8


mainArr = ['YppLife/Resources/webp/bx_login_backView.webp','YppLife/Resources/Sounds/order_completed_biggie.wav','YppLife/Images.xcassets/Register/bx_register_guid_together_done',
           'YppLife/Images.xcassets/Register/bx_register_guid_together_next']

bxArr = ['BXDoraemonPlugins/Pods/Resources/music.m4a']

yrArr = ['Personal/img_intimate_pattern_bg.imageset/img_intimate_pattern_bg@3x.png','Common/cr_singingMenu_bgX.imageset/cr_singingMenu_bgX.png',
         'Common/cr_default_bgX.imageset/cr_default_bgX@3x.png','ChatRoomResource.bundle/cr_player_float_icon.png','ChatRoomResource.bundle/chatroom_sound_wave.png',
         'ChatRoomResource.bundle/cr_redpacket_open_global.svga','ChatRoomResource.bundle/cr_ktv_song_bg_icon.png','ChatRoomResource.bundle/cr_redpacket_open_global_newYear.svga',
         'ChatRoomResource.bundle/cr_redpacket_global_entry.png','ChatRoomResource.bundle/cr_redpacket_open_bg.svga','ChatRoomResource.bundle/cr_redpacket_global_entry_newYear.png',
         'ChatRoomResource.bundle/redpacket_bg.png','ChatRoomResource.bundle/cr_redpacket_open_normal.svga','ChatRoomResource.bundle/cr_personal_shakepeople_info_bar_icon.png',
         'ChatRoomResource.bundle/cr_redpacket_normal_newYear.svga','CRHomeList.xcassets/cr_dispatch_video_cover_img.imageset/cr_dispatch_video_cover_img@3x.png']

xyzArr = ['videolink/xyz_live_anchor_shark_choose_fail.apng','XYZLiveAudience/Pods/Resources/apng/guide_gift_draw.apng',
          'XYZLiveAudience/Pods/Resources/svga/xyz_animation_game_room.svga','XYZLiveAudience/Pods/Resources/apng/xyz_live_faceLink_pk_buff_red.apng',
          'XYZLiveAudience/Pods/Resources/apng/xyz_live_shark_game_redpack_ani.apng','XYZLiveStrawberryGuide.mp4','XYZPlayer/Pods/Resources/apng/xyz_player_loading.png']

orderArr = ['BXOrderBusiness/Pods/Resources/bx_order_findGod_gradientLayer.png','BXOrderBusiness/Pods/Resources/bx_quick_order_center_bowen.png']

gameArr = ['YPPGame/Pods/Resources/HYYakuHei-85W.ttf']


whiteConfigArr = mainArr + bxArr + yrArr + xyzArr + orderArr + gameArr





def getWhiteConfigArr():
	print "====whiteBigConfigArr获取======"
	return whiteConfigArr