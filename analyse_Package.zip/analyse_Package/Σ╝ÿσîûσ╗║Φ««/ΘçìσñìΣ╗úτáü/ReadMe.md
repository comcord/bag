```
python getCycleCode.py /Users/feijunjie/Desktop/比心/BXLife/Pods 120
```

参数1：要检测的代码文件夹

参数2：重复数，建议100以上