#encoding: utf-8
#coding: utf-8
import sys
import os
import shutil
from xml.dom.minidom import parse
import xml.dom.minidom
import pdfkit
fatherPath = os.path.join(sys.path[0],"../../")
sys.path.append(fatherPath) 
import podConfig

if len(sys.argv) < 2:
	print "要检测的目录为空，请正确执行脚本"
	exit(0)
print "要检测的目录是：" + sys.argv[1]
tokenNum = 100
if len(sys.argv) > 2 and int(sys.argv[2]) > 50:
	tokenNum = int(sys.argv[2])
	print "检测重复匹配数为：" + str(tokenNum)
else:
	print "检测重复匹配数为：" + str(tokenNum)  + "，默认为100"
	
print "检测中..比较耗时，请稍等几分钟"

currentPath = sys.path[0]
report_path = os.path.join(currentPath,"重复代码文件.xml")
if os.path.exists(report_path):
	os.remove(report_path)


os.system('pmd cpd --files %s --minimum-tokens %s --language objectiveC --encoding UTF-8 --format xml --skip-lexical-errors > %s' % (sys.argv[1],str(tokenNum),report_path))

print "正在解析数据..."


#分类方法
#两个参数：1.分类选项数组(bx，yr，xyz等)，2.遍历的初始数组
def getDetailSort(output_module_map, cycleArray):
    helper = podConfig.podConfigClass()
    sortArr = helper.configDetail(output_module_map,cycleArray)
    return sortArr


def writeInTableFile(fh,pathArr,titleName):
	if not pathArr:
		return
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<br>')
	fh.write('<font size="5" color="red">%s：</font>' % titleName)
	
	for pathDic in pathArr:
		eleName = list(pathDic)[0]
		elePathArr = list(pathDic.values())[0]
		fh.write('<table border="1">')
		fh.write('<tr><th>codePath</th><th>beginLine / 行</th><th>endLine / 行</th><tr>')
		for detailDic in elePathArr:
			detailPath = detailDic['path']
			detailLine = detailDic['line']
			detailEndLine = detailDic['endline']
			fh.write('<tr><td>%s</td><td style="text-align:center;vertical-align:middle;">%s</td><td style="text-align:center;vertical-align:middle;">%s</td></tr>' % (detailPath, detailLine, detailEndLine))
		pass

	fh.write("</table>")



def queryArrInTableFile(fh,pathArr,titleName):
	if not pathArr:
		return
	fh.write('<br>')
	fh.write('<font size="4" color="black">%s：%s 组</font>' % (titleName, len(pathArr)))


# 使用minidom解析器打开 XML 文档
DOMTree = xml.dom.minidom.parse(report_path)
collection = DOMTree.documentElement
print "11111"
print collection
print "3333"

#获取所有无用代码的集合
codes = collection.getElementsByTagName("duplication")

codeLastArr = []
for code in codes:
	# print "****Code****"
	# lines = code.getAttribute('lines')
	# print "lines == %s" % lines
	files = code.getElementsByTagName('file')
	fileArr = []
	if files:
		fileOne = files[0]
		lastOne = fileOne.getAttribute('path').split('BXLife/Pods/')[-1]
		fileKey = lastOne.split('/')[0]
		pass
	for currentFile in files:
		currentLine = currentFile.getAttribute('line')
		currentEndLine = currentFile.getAttribute('endline')
		currentPath = currentFile.getAttribute('path').split('BXLife/Pods/')[-1]
		fileArr.append({"line": str(currentLine), "endline": str(currentEndLine), "path": str(currentPath)})
		# print "currentLine == %s" % currentLine
		# print "currentEndLine == %s" % currentEndLine
		# print "currentPath == %s" % currentPath
	codeLastArr.append({str(fileKey): fileArr})
	# print "key == %s" % fileKey
	# print ""

print codeLastArr

output_module_map = {"bx": [], "yr": [], "xyz": [], "other": [], "order": [], "arch": [], "self": [],
                         "thirdPart": [], "game": []}
output_module_map = getDetailSort(output_module_map,codeLastArr)

# print "bx:"
# print ""
# print output_module_map["bx"]

# print "yr:"
# print ""
# print output_module_map["yr"]

# print "xyz:"
# print ""
# print output_module_map["xyz"]

# print "order:"
# print ""
# print output_module_map["order"]

# print "game:"
# print ""
# print output_module_map["game"]

# print "arch:"
# print ""
# print output_module_map["arch"]

# print "self:"
# print ""
# print output_module_map["self"]

# print "thirdPart:"
# print ""
# print output_module_map["thirdPart"]

# print "other:"
# print ""
# print output_module_map["other"]

currentPath = sys.path[0]
outPut_Path = os.path.join(currentPath,"html")
if os.path.exists(outPut_Path):
	shutil.rmtree(outPut_Path)

os.mkdir(outPut_Path)

pod_resoureHtml_path = os.path.join(currentPath,"html/cycleCode.html")


fh = open(pod_resoureHtml_path, 'w')
fh.write('<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>')
fh.write('<font size="5" color="red">重复代码归类：</font>')
fh.write('<br>')
fh.write('<font size="4" color="black">检测匹配最小数：%s</font>' % tokenNum)
fh.write('<br>')
fh.write('<br>')
fh.write('<font size="4" color="blue">本次检测查询得到的业务组如下：</font>')
fh.write('<br>')
queryArrInTableFile(fh,output_module_map["bx"],"比心BX")
queryArrInTableFile(fh,output_module_map["yr"],"鱼耳yr")
queryArrInTableFile(fh,output_module_map["xyz"],"直播xyz")
queryArrInTableFile(fh,output_module_map["order"],"陪玩order")
queryArrInTableFile(fh,output_module_map["game"],"小游戏game")
queryArrInTableFile(fh,output_module_map["arch"],"架构相关")
queryArrInTableFile(fh,output_module_map["self"],"自研相关")
queryArrInTableFile(fh,output_module_map["thirdPart"],"第三方相关")
queryArrInTableFile(fh,output_module_map["other"],"其他")

fh.write('<br>')
fh.write('<br>')
fh.write('<br>')
fh.write('<font size="4" color="blue">详情如下：</font>')

writeInTableFile(fh,output_module_map["bx"],"比心BX")
writeInTableFile(fh,output_module_map["yr"],"鱼耳yr")
writeInTableFile(fh,output_module_map["xyz"],"直播xyz")
writeInTableFile(fh,output_module_map["order"],"陪玩order")
writeInTableFile(fh,output_module_map["game"],"小游戏game")
writeInTableFile(fh,output_module_map["arch"],"架构相关")
writeInTableFile(fh,output_module_map["self"],"自研相关")
writeInTableFile(fh,output_module_map["thirdPart"],"第三方相关")
writeInTableFile(fh,output_module_map["other"],"其他")
fh.close()

pdfkit.from_file(pod_resoureHtml_path,os.path.join(currentPath,"html/%s" % "cycleCode.pdf"))
