# encoding: utf-8
# coding: utf-8
import os
import copy

class podConfigClass():
    """docstring for ClassName"""
    #两个参数：1.分类选项数组(bx，yr，xyz等)，2.遍历的初始数组
    def configDetail(self,output_module_map,cycleArray):
        # 比心业务组件 "BX" start
        bx_module_list = ["Lux","ZedPhotosPicker","YppIMDB","PopupDialogs","ypp-router-bx-autogen","YppImageCropKit",
                          "YppUIFramework","DoricBXCommon","HJTabViewController","YppDevelopKit","YppMessage"]
        # 鱼儿组件 "CR" or "YR" or "Sona" start
        yr_module_list = ["ChatRoom","tensorflow-lite","YppAudioEffect","ZedUI","YppStatistics","Ceres","CRUnit","ZedToolkit","YPPPattern",
                          "YppBubbleMaker","Denoise","Demeter","CMNIconFont","YppCommonImages","YppAudioPrep"]

        #社区
        sq_module_list = ["BXContentBusiness","BXTopicBusiness","BXExploration","BXAssetPickerImages","YppAVFoundation","YppFizz",
                          "YppNetWork","YppSentry","YppScrollLink"]
        # 小星球组件 "XYZ" start
        xyz_module_list = ["BXLive", "YppHybrid","YppCommonBridge","YPPSuperPlayer"]
        # 小游戏
        game_module_list = ["YPPGame", "YPPGameBIXIN","YppCocos","cocos2d"]
        # 陪玩
        order_module_list = ["BXAboutMe", "BXOrderBusiness", "BXGodBusiness","ENTPersonalRoom"]
        # 架构
        arch_module_list = ["YppApiSign","YppAVPlayer","YppAVStreamer","DoricCore","YppVideoPlayer","DoricYPPMedia","DoricDevkit"]

        #自研库
        self_module_list = ["HermesSDK","HermesDB","SmAntiFraud","YPPTabViewController","YppToolkit","YppAuthenticationCenter","CrashReporter",
                            "DoricYPPCommon","HermesChannel","YPPLog","YppJsonLabel","MercuryService","DoricLux","YppSpecificationImage","YppVideoPlayer",
                            "YppShare","YppSoraka","YppUploadMediaManager","IronDome","YppBaseNetWork","Lighting","YppBadge","YppMvvm","YppLocation",
                            "YppDoricDownloadManager","YppPushService","YPPCATCrash","YppLarkify","YppAmumu","YppIapManager","YppGiftPlayer",
                            "YppAudioRecorder","YppLego","YPPCATMonitor","YppConfigure","ArThur","BaseNetUtil","YppABTest","YppKayle","YppCache",
                            "YppEnvironmentService","YppAccountService","YppSynchronize","YppLayout","YppProtocol","MercuryFramework","PhoneNetSDK"]
        #三方库
        thirdPart_module_list = ["DLNAFramework","HappyDNS","PLMediaStreamingKit","ZegoSDK","AliyunIdentityManager","NIMSDK","NUISDK",
                                 "Weibo_SDK","TXLiteAVSDK_Professional","tiny_opencv2","GeYanSdk","GTSDK","WCDB","QCloudCore","UMCommon","WBOCRService",
                                 "YYText","WBCloudReflectionFaceVerify","TuringShieldCamRisk","Protobuf","GTCommonSDK-1","TencentOpenAPI","QCloudCOSXML",
                                 "ReactiveCocoa","WeiboSDK","WeChatSDK","KTVHTTPCache","QGVAPlayer","AFNetworking","CocoaAsyncSocket","YTFaceAlignmentTinyLiveness",
                                 "YTCommon","pop","Qiniu","YTFaceLiveReflect","KTVCocoaHTTPServer","YppNerdyUI","YTKNetwork","YYWebImage","SVGAPlayer",
                                 "YTFaceDetectorLiveness","SSZipArchive","YTFaceTrackerLiveness","PhoenixSDK","YYImage","YTImageRefiner","MJRefresh",
                                 "YTPoseDetector","Masonry","YYCache","UMDevice","SmCaptcha","MJExtension","RealReachability","MarqueeLabel","Yoga",
                                 "MBProgressHUD","UICKeyChainStore","Aspects","TYSnapshotScroll","YogaKit","WebP","SDVersion","YYKeyboardManager","AnimationEngine",
                                 "DACircularProgress","TYSnapshotAuxiliary","UICountingLabel","SZTextView","UMCCommon","AMapFoundationKit","AMapSearchKit",
                                 "AMapLocationKit","st_mobile","ToygerService","deviceiOS","APPSecuritySDK","AliyunOSSiOS","APBToygerFacade","BioAuthEngine",
                                 "MPRemoteLogging","ZolozUtility","ZolozOpenPlatformBuild","ZolozSensorServices","BioAuthAPI","Platinum","Neptune","tnn",
                                 "NMC","FLEX","DoraemonKit","WBCommonService","YppBlockMonitor","YPPOOMDetector","AlipaySDK","SDWebImage","TencentCloudHuiyanSDKFace",
                                 "BytedEffect","effect-sdk"]

        main_module_list = ["linker synthesized","System","c++","CoreGraphics","CoreFoundation","OpenGLES","objc","CoreText","clang_rt","CoreMedia",
                            "AudioToolBox","Security","CoreVideo","UIKit","CFNetwork","Accelerate","dtrace","VideoToolbox","Foundation","OpenAL","z",
                            "ImageIO","SystemConfiguration","QuartzCore","resolv","Pods-YppLife","main","CoreServices","CoreLocation","MapKit","AVFoundation",
                            "MetalPerformanceShaders","Metal","c++abi","c++"]



        for item in cycleArray:
            podName = list(item)[0]
            if podName.startswith('BX'):
                output_module_map["bx"].append(item)
                continue
            if podName.startswith('CR') or podName.startswith('YR') or podName.startswith('Sona'):
                output_module_map["yr"].append(item)
                continue
            if podName.startswith('XYZ'):
                output_module_map["xyz"].append(item)
                continue
            for bx_module in bx_module_list:
                if bx_module in podName:
                    output_module_map["bx"].append(item)
                    break
            else:
                for yr_module in yr_module_list:
                    if yr_module in podName:
                        output_module_map["yr"].append(item)
                        break
                else:
                    for xyz_module in xyz_module_list:
                        if xyz_module in podName:
                            output_module_map["xyz"].append(item)
                            break
                    else:
                        for game_module in game_module_list:
                            if game_module in podName:
                                output_module_map["game"].append(item)
                                break
                        else:
                            for order_module in order_module_list:
                                if order_module in podName:
                                    output_module_map["order"].append(item)
                                    break
                            else:
                                for arch_module in arch_module_list:
                                    if arch_module in podName:
                                        output_module_map["arch"].append(item)
                                        break
                                else:
                                    for self_module in self_module_list:
                                        if self_module in podName:
                                            output_module_map["self"].append(item)
                                            break
                                    else:
                                        for thirdPart_module in thirdPart_module_list:
                                            if thirdPart_module in podName:
                                                output_module_map["thirdPart"].append(item)
                                                break
                                        else:
                                            for sq_module in sq_module_list:
                                                if sq_module in podName:
                                                    output_module_map["sq"].append(item)
                                                    break
                                            else:
                                                for main_module in main_module_list:
                                                    if main_module in podName:
                                                        output_module_map["main"].append(item)
                                                        break
                                                else:
                                                    output_module_map["other"].append(item)
        # print "jjjjjj========"
        bxCopyArr = copy.deepcopy(output_module_map["bx"])
        for item in bxCopyArr:
            podName = list(item)[0]
            if "BXLive" in podName:
                output_module_map["bx"].remove(item)
                output_module_map["xyz"].append(item)
                continue
            if ("BXAboutMe" in podName) or ("BXOrderBusiness" in podName) or ("BXGodBusiness" in podName):
                output_module_map["bx"].remove(item)
                output_module_map["order"].append(item)
                continue
            if ("BXContentBusiness" in podName) or ("BXTopicBusiness" in podName) or ("BXExploration" in podName) or ("BXAssetPickerImages" in podName):
                output_module_map["bx"].remove(item)
                output_module_map["sq"].append(item)
                continue
            pass

        return output_module_map


    #配置名称缩写，每个名称缩写后面跟个空数组
    def configSort(self):
        output_module_map = {"bx": [], "yr": [], "sq": [], "order": [], "xyz": [], "game": [],"arch": [], "self": [],
                            "thirdPart": [], "main": [], "other": []}
        return output_module_map
        pass


    #名称对应，用来输出展示的，这些的key需要和上面的configSort中的名称缩写一样（除去other），这里main也是要的，表示主工程。
    def configName(self):
        output_module_map = [{"bx": "基础业务"},
                            {"yr": "语音"},
                            {"sq": "社区"},
                            {"order": "陪玩"},
                            {"xyz": "直播"},
                            {"game": "小游戏"},
                            {"arch": "架构"},
                            {"self": "自研基础库"},
                            {"thirdPart": "三方库"},
                            {"main": "主工程"}]
        return output_module_map
        pass

    #获取工程名字
    def getProjectName(self):
        return "YppLife"












