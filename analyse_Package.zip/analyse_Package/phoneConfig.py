#encoding: utf-8
#coding: utf-8

#如果这个人不在群里，却有他的问题，会@出来电话号码
#确保这个人在群里，再配置他的名字
namePhoneDic = {"费俊杰": "18756921531"}#"李军灼": "18521067837"
nameEmailDic = {"费俊杰": "feijunj@163.com"}



def getNamePhoneDic():
	return namePhoneDic

def getNameEmailDic():
	return nameEmailDic

def getPhoneArr():
	phoneArr = []
	for value in namePhoneDic.values():
		phoneArr.append(value)
	return phoneArr

def getEmailArr(nameArr):
	emailArr = []
	for valueName in nameArr:
		value = nameEmailDic.setdefault(valueName, "")
		# print "value =" + value
		if value:
			emailArr.append(nameEmailDic[valueName])
		pass
	# print "lastArr == " + str(emailArr)
	return emailArr

# if __name__=="__main__":
#     tt = getNamePhoneDic()
#     aa = getPhoneArr()
#     print "tttt == " + str(tt)
#     print "aaa == " + str(aa)