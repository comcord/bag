#encoding: utf-8
#coding: utf-8
import requests
import json
import smtplib
import json
import os
import sys
from email.mime.text import MIMEText
import phoneConfig
from email.mime.multipart import MIMEMultipart

currentHeader = (sys.path[0]).split('Res/analyse_Package')[0]
fatherPath = os.path.join(currentHeader,"Res/analyse_Package")


def getPhoneWithName(nameStr):
	telPhone = namePhoneDic.setdefault(nameStr, "")
	if telPhone:
		# print "junnn == " + telPhone
		return telPhone
	else:
		# print "123"
		return ""
	pass

namePhoneDic = phoneConfig.getNamePhoneDic()

#moduleNameArr = [titleName: [{moduleStr:[nameStr,count]}]]
#titleName:治理名称
def dingmessage(moduleNameArr,branchName):
	namePhoneDic = phoneConfig.getNamePhoneDic()
	# print "ddddd == name ==" + str(namePhoneDic)
	# print "ttttt == " + str(phoneConfig.getPhoneArr())
	# 请求的URL，WebHook地址
	webhook = "https://oapi.dingtalk.com/robot/send?access_token=9451e78289f9011fe9de6d88a8e840aa09934cd3c44cba3f78b4dc94ac7d1ef7"
	#构建请求头部
	header = {
		"Content-Type": "application/json",
        "Charset": "UTF-8"
        }

	#构建请求数据
	tex="\n"
	tex=tex+branchName+"\n"
	tex=tex+"邮箱地址查看：https://exmail.qq.com/cgi-bin/frame_html?sid=G35BkONc7rJ4BylI,7&sign_type=&r=8b72959c7558c2ad3233557ef46c95c9\n"
	for elementDic in moduleNameArr:
		tex + "\n"
		eleClassName = list(elementDic)[0]
		tex = tex + ' \n' + eleClassName + "：\n"
		eleClassArrs = list(elementDic.values())[0]
		for eleSubEleDic in eleClassArrs:
			eleSubEleName = list(eleSubEleDic)[0]
			eleSubEleArr = list(eleSubEleDic.values())[0]
			owner = eleSubEleArr[0]
			count = eleSubEleArr[1]
			telPhone = getPhoneWithName(owner)
			if not telPhone:
				telPhone = owner
				pass
			tex = (tex + "@%s：" + "%s模块" + "有%s个问题待解决，请移步到邮箱查看" + "\n") % (telPhone,eleSubEleName,count)
			pass

	contentStr = (("包体统计：" + tex))
	message ={

        "msgtype": "text",
        "text": {
            "content": contentStr
        },
        "at": {

            "isAtAll": False,
            "atMobiles":phoneConfig.getPhoneArr()
        }
    }

    #对请求的数据进行json封装
	message_json = json.dumps(message)

    #发送请求
	info = requests.post(url=webhook,data=message_json,headers=header)
    #打印返回的结果
	print(info.text)



def emailmessage(moduleNameArr):
	#设置服务器所需信息
	#163邮箱服务器地址
	mail_host = 'smtp.exmail.qq.com'  
	#用户名
	mail_user = 'feijunjie@bixin.cn'  
	#密码(部分邮箱为授权码) 
	mail_pass = '0909zjyW'   


	#邮件发送方邮箱地址
	sender = 'feijunjie@bixin.cn'  
	#邮件接受方邮箱地址，注意需要[]包裹，这意味着你可以写多个邮件地址群发
	postNameArr = []
	for elementDic in moduleNameArr:
		eleClassArrs = list(elementDic.values())[0]
		for eleSubEleDic in eleClassArrs:
			eleArrs = list(eleSubEleDic.values())[0]
			owner = eleArrs[0]
			if owner in postNameArr:
				pass
			else:
				postNameArr.append(owner)
			pass
	receivers = phoneConfig.getEmailArr(postNameArr)
	print "应发送邮件的名单：" + str(postNameArr)

	#设置email信息
	#邮件内容设置
	# message = MIMEText('一会发个附件给你','plain','utf-8')

	#添加一个MIMEmultipart类，处理正文及附件
	message = MIMEMultipart()

	message.attach(MIMEText('点击查看附件内容，解锁更多','plain','utf-8'))


	#邮件主题       
	message['Subject'] = '比心包体治理有你的快递'
	#发送方信息
	message['From'] = sender 
	#接受方信息     
	# message['To'] = receivers[0]

	for elementDic in moduleNameArr:
		eleClassName = list(elementDic)[0]
		eleClassArrs = list(elementDic.values())[0]
		htmlPath = getHtmlPath(eleClassName)
		print "htmlPath == " + htmlPath
		#推荐使用html格式的正文内容，这样比较灵活，可以附加图片地址，调整格式等
		with open(htmlPath,'rb') as f:
			content = f.read()
		#设置html格式参数
		part1 = MIMEText(content,'html','utf-8')
		#附件设置内容类型，方便起见，设置为二进制流
		part1['Content-Type'] = 'application/octet-stream'
		#设置附件头，添加文件名
		part1['Content-Disposition'] = 'attachment;filename="%s.html"' % eleClassName
		#将内容附加到邮件主体中
		message.attach(part1)
		pass


	#登录并发送邮件
	try:
		# smtpObj = smtplib.SMTP() 
        #连接到服务器
        # smtpObj.connect(mail_host,465)
		smtpObj = smtplib.SMTP_SSL(mail_host,465)
		# smtp.ehlo()
        # smtp.starttls()
        #登录到服务器
		smtpObj.login(mail_user,mail_pass) 
		#发送
		smtpObj.sendmail(
        	sender,receivers,message.as_string()) 
        #退出
		smtpObj.quit() 
		print('success')

	except smtplib.SMTPException as e:
		print('error',e) #打印错误
	pass


def getHtmlPath(moduleName):
	htmlName = 'bigPic'
	superName = '获取工程大图'
	if '无用资源' in moduleName:
		htmlName = 'UnusedPic'
		superName = '无用资源'
	else:
		if '大资源' in moduleName:
			htmlName = 'bigPic'
			superName = '获取工程大图'
		else:
			if '重复资源' in moduleName:
				htmlName = 'repeatPic'
				superName = '重复资源'
			else:
				if '无用类' in moduleName:
					htmlName = 'uselessCode'
					superName = '无用代码'
					pass
	htmlPath = os.path.join(fatherPath,"优化建议/%s/html/%s.html" % (superName,htmlName))
	return htmlPath


# if __name__=="__main__":
#     dingmessage()
